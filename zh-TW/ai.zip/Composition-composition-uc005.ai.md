# 成人預防保健檢查報告組成文件範例 (UC-005) - 臺灣勞工健康檢查交換實作指引 (Taiwan Labor Health Examination Exchange FHIR IG, TWHA IG) v0.7.1

## 範例 Composition: 成人預防保健檢查報告組成文件範例 (UC-005)

Profile: [健康檢查健檢報告組成結構 Profile](StructureDefinition-TWHA-Composition.md)

**status**: Final

**type**: Laboratory report

**date**: 2026-06-12 11:45:00+0800

**author**: [Practitioner 林職醫(official)](Practitioner-example-doctor.md)

**title**: 成人預防保健檢查報告



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "composition-uc005",
  "meta" : {
    "profile" : ["https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"]
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "11502-2",
      "display" : "Laboratory report"
    }]
  },
  "subject" : {
    "reference" : "Patient/example-worker"
  },
  "date" : "2026-06-12T11:45:00+08:00",
  "author" : [{
    "reference" : "Practitioner/example-doctor"
  }],
  "title" : "成人預防保健檢查報告",
  "section" : [{
    "title" : "基本資料與行政資訊",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "51847-2"
      }]
    },
    "entry" : [{
      "reference" : "Patient/example-worker"
    },
    {
      "reference" : "Encounter/example-encounter-general"
    }]
  },
  {
    "title" : "醫師總評、分級與建議",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "51848-0"
      }]
    },
    "entry" : [{
      "reference" : "ClinicalImpression/example-clinical-impression"
    },
    {
      "reference" : "Procedure/example-procedure-counseling"
    }]
  },
  {
    "title" : "自覺症狀",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "29554-3"
      }]
    },
    "entry" : [{
      "reference" : "QuestionnaireResponse/adult-preventive-care-response"
    },
    {
      "reference" : "QuestionnaireResponse/sdoh-questionnaire-response"
    }]
  },
  {
    "title" : "理學檢查",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "29545-1"
      }]
    },
    "entry" : [{
      "reference" : "Observation/obs-height"
    },
    {
      "reference" : "Observation/obs-weight"
    },
    {
      "reference" : "Observation/obs-bmi"
    },
    {
      "reference" : "Observation/obs-waist"
    },
    {
      "reference" : "Observation/obs-bloodpressure"
    }]
  },
  {
    "title" : "檢驗與影像檢查",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "30954-2"
      }]
    },
    "entry" : [{
      "reference" : "Observation/obs-lab-glucose"
    }]
  }]
}

```
