# Resource 臺灣勞工健康檢查交換實作指引 (Taiwan Labor Health Examination Exchange FHIR IG, TWHA IG)



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "mohw.tw.twha",
  "language" : "zh-TW",
  "url" : "https://twcore.mohw.gov.tw/ig/twha/ImplementationGuide/mohw.tw.twha",
  "version" : "0.1.0",
  "name" : "TWHAIG",
  "title" : "臺灣勞工健康檢查交換實作指引 (Taiwan Labor Health Examination Exchange FHIR IG, TWHA IG)",
  "status" : "active",
  "date" : "2026-07-29T09:46:30+00:00",
  "publisher" : "衛生福利部次世代數位醫療平臺專案辦公室 & 長庚醫療財團法人長庚紀念醫院",
  "contact" : [{
    "name" : "衛生福利部次世代數位醫療平臺專案辦公室 & 長庚醫療財團法人長庚紀念醫院",
    "telecom" : [{
      "system" : "url",
      "value" : "https://twcore.mohw.gov.tw/twregistry/"
    }]
  },
  {
    "name" : "衛生福利部次世代數位醫療平臺專案辦公室",
    "telecom" : [{
      "system" : "url",
      "value" : "https://twcore.mohw.gov.tw/twregistry/"
    }]
  }],
  "description" : "以勞工健康檢查為核心之 FHIR 資料交換標準，繼承臺灣核心實作指引 (TW Core IG)，並可向特殊職類與一般健康檢查／成人預防保健需求擴充。【canonical 為 provisional：正式命名空間之核定機關與命名尚待確認，宜先定治理再定 namespace。】",
  "packageId" : "mohw.tw.twha",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.3.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "tw_gov_mohw_twcore",
    "uri" : "https://twcore.mohw.gov.tw/ig/twcore/ImplementationGuide/tw.gov.mohw.twcore",
    "packageId" : "tw.gov.mohw.twcore",
    "version" : "1.0.0"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2026+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "STU1"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "zh-TW"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-multiples"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://kunjulin.github.io/occupationIG/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewAmount-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewBeh-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewQuit-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewYear-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-ObserBeh-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewAmount-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewBeh-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewQuit-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewYear-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-CoreDataset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-ExtendedDataset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-OccHealthCheck-Required"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-PulmonaryFunction"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-TWHAVitalSigns"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-UnfitDiseases"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2026+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "STU1"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "zh-TW"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-multiples"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://kunjulin.github.io/occupationIG/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewAmount-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewBeh-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewQuit-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewYear-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-ObserBeh-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewAmount-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewBeh-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewQuit-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewYear-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-CoreDataset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-ExtendedDataset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-OccHealthCheck-Required"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-PulmonaryFunction"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-TWHAVitalSigns"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-UnfitDiseases"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-sdoh-questionnaire-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/sdoh-questionnaire-response"
      },
      "name" : "SDOH 社會決定因素問卷回覆實例",
      "description" : "王大同的精簡版 PRAPARE 社會風險問卷回覆結果。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SDOH-QuestionnaireResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "OperationDefinition-Bundle-submit.html"
      }],
      "reference" : {
        "reference" : "OperationDefinition/Bundle-submit"
      },
      "name" : "Submit Bundle Operation",
      "description" : "健檢機構向主管機關平台上傳健檢資料之作業。輸入為符合 TWHA-Bundle-Transaction 之上傳封包；去重規則：Patient／Organization 以識別碼條件式建立（ifNoneExist）、DiagnosticReport 以報告識別碼（https://twcore.mohw.gov.tw/ig/twha/sid/report-id）條件式更新，同一份報告重傳為覆寫（冪等）。成功回傳 transaction-response Bundle；驗證失敗回傳 OperationOutcome，issue.expression 指向出錯之 entry。整包處理語意（transaction 全有全無 vs batch 部分成功）為未決事項 M-9，定案前平台端不得依任一語意實作錯誤處理。完整契約見 conformance.html 之「上傳介接契約」一節。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-001.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-001"
      },
      "name" : "UC-001 一般健康檢查報告封包",
      "description" : "一般健康檢查結果 Document Bundle 打包範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-002.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-002"
      },
      "name" : "UC-002 勞工一般體格與健康檢查報告封包",
      "description" : "勞工一般健康檢查結果 Document Bundle 打包範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-003.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-003"
      },
      "name" : "UC-003 特殊危害健康作業檢查報告封包",
      "description" : "噪音/鉛/粉塵等特殊危害健康作業檢查報告封包。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-004.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-004"
      },
      "name" : "UC-004 企業自費健康檢查報告封包",
      "description" : "企業自費健檢報告封包，包含自費影像檢查及內視鏡檢查項目。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-005.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-005"
      },
      "name" : "UC-005 成人預防保健檢查報告封包",
      "description" : "國健署成人預防保健自填問卷與理學生化檢查 Document Bundle 範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-006.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-006"
      },
      "name" : "UC-006 勞工健康服務臨場服務紀錄封包",
      "description" : "臨場服務紀錄 Composition（附表八）與關聯活動資料 Document Bundle 範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-007.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-007"
      },
      "name" : "UC-007 職業健康急診友善摘要封包",
      "description" : "急診友善摘要 Composition（含鉛作業暴露史、生命徵象、關鍵檢驗值與缺值示範）之 Document Bundle 範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-008.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-008"
      },
      "name" : "UC-008 一般健檢結果上傳封包（首次上傳）",
      "description" : "健檢機構向主管機關平台上傳一般健檢結果之 Transaction Bundle。示範：urn:uuid 內部參照、Patient／Organization 以識別碼條件式建立（ifNoneExist）達成去重、DiagnosticReport 以報告識別碼（sid/report-id）條件式建立。處理語意（transaction／batch）為未決事項 M-9。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Transaction"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-009.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-009"
      },
      "name" : "UC-009 特殊健檢結果上傳封包（含缺值與冪等重傳）",
      "description" : "健檢機構上傳特殊危害健康作業（鉛作業）檢查結果之 Transaction Bundle。示範：DiagnosticReport 以報告識別碼（sid/report-id）做**條件式更新（PUT）**——同一份報告重傳為覆寫而非新增，達成冪等；檢驗缺值以 dataAbsentReason 標明；暴露史因 result 之上游限縮（T-10）不置於 report.result。處理語意（transaction／batch）為未決事項 M-9。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Transaction"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-BetNutChewBeh-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-BetNutChewBeh-codesystem"
      },
      "name" : "【本地 stub】Betel Nut Chewing Behavior Code System（非權威定義）",
      "description" : "Betel Nut Chewing Behavior Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-BetNutChewYear-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-BetNutChewYear-codesystem"
      },
      "name" : "【本地 stub】嚼檳榔年代碼系統（非權威定義）",
      "description" : "Betel Nut Chewing Year Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-sf-BetNutChewYear-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/sf-BetNutChewYear-valueset"
      },
      "name" : "【本地 stub】嚼檳榔年值集（非權威定義）",
      "description" : "Betel Nut Chewing Year Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-sf-BetNutChewBeh-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/sf-BetNutChewBeh-valueset"
      },
      "name" : "【本地 stub】嚼檳榔行為值集（非權威定義）",
      "description" : "Betel Nut Chewing Behavior Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-BetNutChewQuit-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-BetNutChewQuit-codesystem"
      },
      "name" : "【本地 stub】戒嚼檳榔年代碼系統（非權威定義）",
      "description" : "Betel Nut Chewing Quit Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-sf-BetNutChewQuit-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/sf-BetNutChewQuit-valueset"
      },
      "name" : "【本地 stub】戒嚼檳榔年值集（非權威定義）",
      "description" : "Betel Nut Chewing Quit Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-BetNutChewAmount-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-BetNutChewAmount-codesystem"
      },
      "name" : "【本地 stub】每日嚼檳榔量代碼系統（非權威定義）",
      "description" : "Betel Nut Chewing Amount Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-sf-BetNutChewAmount-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/sf-BetNutChewAmount-valueset"
      },
      "name" : "【本地 stub】每日嚼檳榔量值集（非權威定義）",
      "description" : "Betel Nut Chewing Amount Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-ObserBeh-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-ObserBeh-codesystem"
      },
      "name" : "【本地 stub】相關行為代碼系統（非權威定義）",
      "description" : "Observation Behavior Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc001.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc001"
      },
      "name" : "一般健檢報告組成文件範例 (UC-001)",
      "description" : "整合王大同一般健康檢查所有關聯項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-LabResult-General.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-LabResult-General"
      },
      "name" : "一般健檢實驗室檢驗 Profile",
      "description" : "用於記錄勞工一般體格與健康檢查之實驗室檢驗結果，如血液、尿液及生化項目，繼承自 TW Core Lab Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-UnfitDiseases.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-UnfitDiseases"
      },
      "name" : "不適合從事作業之疾病值集",
      "description" : "依據勞工健康保護規則附表十二所列，不適合從事特定特別危害健康作業之疾病代碼值集（以 ICD-10-CM 表示）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-CoreUploadSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-CoreUploadSet"
      },
      "name" : "主管機關最小共通上傳集（國健署原案 21 列，跨值集群組）",
      "description" : "群組值集：組合 Core 之檢驗子集（VS-CoreDataset）、生理量測（VS-TWHAVitalSigns）與社會史碼，具體化主管機關（國健署）制定之最小共通上傳集（原案 16 主項／21 列，對標 USCDI regulator-defined minimum）。僅供文件與完整度／覆蓋矩陣機器核對，不作 Observation.code 綁定。嚼檳量／嚼檳月數屬本地 Extension（ext-betelnut-quantity），無國際碼，於文件註記。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Composition-ServiceRecord.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Composition-ServiceRecord"
      },
      "name" : "健康檢查健康服務執行紀錄組成結構 Profile",
      "description" : "本 Profile 用於定義臨場健康服務執行紀錄表單（附表八）的文件組成結構，以 Composition 作為文件核心。\n\n**subject／custodian 語意界定（回應委員意見）**：本文件之標的為「**一次臨場服務事件與其紀錄**」，故 `subject` 為受服務之事業單位（作業場所），`custodian` 為保管該紀錄之醫療機構。**惟本 IG 並非一律以 Organization 作 subject**：文件內各關聯資源依其性質分別設定——個人健康指導以 Patient 為 subject、群體衛教以 Group 為 subject、事業單位則以 `serviceProvider`／`custodian`／`focus`／`extension[employerInfo]` 表達，詳見各該 Profile。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-HealthManagementLevel.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-HealthManagementLevel"
      },
      "name" : "健康檢查健康管理分級 Observation Profile",
      "description" : "用於以獨立 Observation 資源記錄受檢勞工健康檢查後，經醫師總評判定之健康管理分級（1-4級）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Composition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Composition"
      },
      "name" : "健康檢查健檢報告組成結構 Profile",
      "description" : "本 Profile 用於定義一般健康檢查、勞工健康檢查及成人預防保健等健康檢查報告的文件組成結構，以 Composition 作為文件核心，並定義各項目的 Section，繼承自 TW Core Composition。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Encounter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Encounter"
      },
      "name" : "健康檢查健檢就醫事件 Profile",
      "description" : "本 Profile 用於描述勞工進行一般體格檢查、一般健康檢查或特殊體格/健康檢查的就醫事件，繼承自 TW Core Encounter。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-ImagingStudy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-ImagingStudy"
      },
      "name" : "健康檢查健檢影像檢查 Profile",
      "description" : "用於記錄勞工胸部 X 光、骨骼 X 光等影像檢查，繼承自 TW Core ImagingStudy。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-DiagnosticReport.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-DiagnosticReport"
      },
      "name" : "健康檢查健檢診斷報告 Profile",
      "description" : "本 Profile 用於彙整勞工體格及健康檢查結果之診斷報告，繼承自 TW Core DiagnosticReport。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-ServiceRequest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-ServiceRequest"
      },
      "name" : "健康檢查健檢追蹤檢查要求 Profile",
      "description" : "針對第三級或需要追蹤之勞工，醫師開立之追蹤檢查或現場評估排程要求，繼承自 TW Core ServiceRequest。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-ClinicalImpression.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-ClinicalImpression"
      },
      "name" : "健康檢查健檢醫師總評與分級 Profile",
      "description" : "用於記錄健檢判定醫師針對勞工檢查結果進行之總體臨床評估、健康管理分級（1-4級）及處置建議。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Bundle-Document.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Bundle-Document"
      },
      "name" : "健康檢查報告交換封包 (Document Bundle) Profile",
      "description" : "用於健檢報告交換的 Document Bundle，其第一個 entry 必須為 Composition（以 twha-bnd-1 不變條件驗證），且型態 (type) 必須為 document。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-exam-interval.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-exam-interval"
      },
      "name" : "健康檢查實施週期擴充",
      "description" : "標註此次健康檢查之實施週期（如每年、每3年、每5年）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Occupation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Occupation"
      },
      "name" : "健康檢查工作經歷與職業別 Profile",
      "description" : "用於記錄受檢勞工之工作經歷與現任職業別，繼承自 TW Core Observation Occupation。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Organization-Employer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Organization-Employer"
      },
      "name" : "健康檢查所屬事業單位（雇主公司） Profile",
      "description" : "本 Profile 用於描述受檢勞工所屬之事業單位或公司，繼承自 TW Core Organization (公司) 以精確反映公司法人組織語義。其中統一編號以 identifier 表示。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Condition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Condition"
      },
      "name" : "健康檢查既往病史與不適作業疾病 Profile",
      "description" : "用於記錄勞工之既往慢性病病史，或醫師判定屬於附表十二不適合從事作業之疾病，繼承自 TW Core Condition。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-CoreDataset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-CoreDataset"
      },
      "name" : "健康檢查核心檢驗項目值集（主管機關最小上傳集之檢驗子集）",
      "description" : "Core 之檢驗子集（主管機關（國健署）最小共通上傳集之 Observation.code 綁定值集，綁定強度 extensible）。僅收錄 Core 之 10 檢驗項 preferred code 及其 acceptable 變異碼；生理量測（身高/體重/腰圍/血壓）碼分屬 VS-TWHAVitalSigns、社會史（吸菸/嚼檳）碼分屬 SocialHistory profile。Core 全集（21 列）之群組見 VS-CoreUploadSet。acceptable→preferred 歸一見 ConceptMap TWHealthCheckLaboratoryMap。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-TWHealthCheckLaboratoryMap.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/TWHealthCheckLaboratoryMap"
      },
      "name" : "健康檢查檢驗項目代碼對應 ConceptMap",
      "description" : "將健康檢查實驗室檢驗之 acceptable code 歸一至 preferred (primary) code。值集綁定採 extensible binding；本 ConceptMap 供接收端將院所 LIS 之可接受變異碼標準化至優先碼。\n\n**來源版本**：LOINC 2.82（經 tx.fhir.org 驗證）。**驗證狀態**：全數 source／target 代碼已於 2026-07-26 完成 $validate-code 代碼有效性驗證。**審查狀態**：equivalence 已於 2026-07-26 依 FHIR 語意逐筆覆核並補列理由（comment），工作小組建議方案，提請確認可否作為下一階段試作基礎。\n\n**equivalence 使用原則**：`equivalent` 僅用於完全等義（同概念、同檢體、方法同為未指定或同一方法）；source 為 target 之方法特化者用 `narrower`；source 語意較廣者用 `wider`；不同具體方法、不同檢體、或需數值換算而無包含關係者用 `relatedto`（R4 之 ConceptMapEquivalence 代碼，語意為「有關聯但確切關係未知」）。\n\n⚠️ **歸一之臨床限制**：本對照供資料標準化之用，**不表示歸一後之數值可直接互換比較**（例如 MDRD 與 CKD-EPI eGFR、IFCC 與 NGSP HbA1c 均需換算或不可互換）。交換時應保留原始代碼。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Questionnaire.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Questionnaire"
      },
      "name" : "健康檢查自覺症狀問卷定義 Profile",
      "description" : "用於定義勞工體格或健康檢查中，自覺症狀調查（附表十一之自覺症狀部分）的問卷結構 Profile。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Bundle-Transaction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Bundle-Transaction"
      },
      "name" : "健康檢查資料上傳封包 (Transaction Bundle) Profile",
      "description" : "用於健檢系統或醫療院所向主管機關平台進行批次上傳/新增資料之 Transaction Bundle，其型態 (type) 必須為 transaction，且 entry 必須包含 HTTP 請求方法資訊。去重與冪等重傳之契約見 conformance.html「上傳介接契約」；整包處理語意（transaction 全有全無 vs batch 部分成功）為未決事項 M-9，若定案採 batch，本 profile 之 type 固定值需隨之調整。範例：UC-008（首次上傳）、UC-009（含缺值與冪等重傳）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-TWHA-CapabilityStatement.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/TWHA-CapabilityStatement"
      },
      "name" : "健康檢查資料交換平台服務宣告",
      "description" : "本實體用於宣告健康檢查資料交換平台支援的交互作用規範，主要採用 POST [base]/Bundle ($submit) 或直接交易封包 (transaction) 進行健檢資料之上傳與交換。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-ExtendedDataset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-ExtendedDataset"
      },
      "name" : "健康檢查進階與領域擴充項目值集",
      "description" : "包含特殊健康檢查與體格檢查之實驗室與生理功能檢驗項目，以及自費健康檢查常見之影像學檢查（如 MRI、CT、PET/CT、超音波、骨密度等）與內視鏡檢查（如胃鏡、大腸鏡），對應至 LOINC 代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-CarePlan.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-CarePlan"
      },
      "name" : "健康檢查適性配工計畫 Profile",
      "description" : "用於針對第四級健康管理勞工，由醫師、事業單位等共同制定之適性配工計畫（變更場所、工作或縮短工時等），繼承自 TW Core CarePlan。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-HealthMgmtLevel.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-HealthMgmtLevel"
      },
      "name" : "健康管理分級代碼系統",
      "description" : "依據勞工健康保護規則第 21 條規定，醫師依健康檢查結果判定之健康管理分級。（**provisional**：本代碼系統為工作小組建議之本地代碼配置，**尚待勞動部職業安全衛生署確認官方代碼與定義（M-2）**；不得表述為已對接官方申報系統。）",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-HealthMgmtLevel.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-HealthMgmtLevel"
      },
      "name" : "健康管理分級值集",
      "description" : "包含健康管理分級（第一級至第四級）代碼之值集。（provisional，隨 CS-HealthMgmtLevel 待官方確認）",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-health-mgmt-level.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-health-mgmt-level"
      },
      "name" : "健康管理分級判定範例 - 第四級管理",
      "description" : "醫師依噪音作業特殊健康檢查結果，判定受檢勞工王大同為第四級健康管理（異常且與工作相關，需適性配工與治療）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-HealthManagementLevel"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-health-mgmt-level.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-health-mgmt-level"
      },
      "name" : "健康管理分級擴充",
      "description" : "記錄醫師針對勞工健康狀況判定之健康管理分級（1-4級）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Procedure-Counseling.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Procedure-Counseling"
      },
      "name" : "健康諮詢與衛教指導 Profile",
      "description" : "用於記錄成人預防保健服務及一般健康檢查中，醫師或醫護團隊提供之健康諮詢、衛教指導與預防教育活動（如戒菸、節酒、腎病識能指導等），繼承自 TW Core Procedure。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-example-procedure-counseling.html"
      }],
      "reference" : {
        "reference" : "Procedure/example-procedure-counseling"
      },
      "name" : "健康諮詢與衛教指導範例",
      "description" : "針對受檢者王大同進行之「規律運動諮詢與衛教」與「腎病識能衛教指導」的紀錄。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Procedure-Counseling"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-HealthCounseling.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-HealthCounseling"
      },
      "name" : "健康諮詢與衛教指導項目代碼系統",
      "description" : "國民健康署成人預防保健服務及一般健康檢查中醫師提供之健康諮詢與衛教指導項目。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-HealthCounseling.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-HealthCounseling"
      },
      "name" : "健康諮詢與衛教指導項目值集",
      "description" : "包含成人預防保健與健康檢查中健康諮詢項目代碼之值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "NamingSystem-NS-ReportIdentifier.html"
      }],
      "reference" : {
        "reference" : "NamingSystem/NS-ReportIdentifier"
      },
      "name" : "健檢報告封包識別碼",
      "description" : "勞工健康檢查報告封包（Bundle）之識別碼命名空間。用於上傳去重、跨機構參照與稽核追溯。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-example-encounter-general.html"
      }],
      "reference" : {
        "reference" : "Encounter/example-encounter-general"
      },
      "name" : "健檢就醫事件範例 - 一般定期健康檢查",
      "description" : "受檢勞工王大同於115年6月12日進行的一般定期健康檢查事件。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Encounter"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-example-encounter-special.html"
      }],
      "reference" : {
        "reference" : "Encounter/example-encounter-special"
      },
      "name" : "健檢就醫事件範例 - 噪音作業特殊健康檢查",
      "description" : "受檢勞工王大同於115年6月12日進行之噪音作業特殊健康檢查事件，以 ext-hazard-type 標註危害作業種類、ext-labor-report-code 標註通報大類。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Encounter"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ImagingStudy"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ImagingStudy-example-imaging-chest-xray.html"
      }],
      "reference" : {
        "reference" : "ImagingStudy/example-imaging-chest-xray"
      },
      "name" : "健檢影像檢查範例 - 胸部 X 光",
      "description" : "粉塵作業勞工之胸部 X 光攝影檢查，單一序列單一影像。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-ImagingStudy"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-example-diagnostic-report.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/example-diagnostic-report"
      },
      "name" : "健檢診斷報告範例 - 噪音作業特殊健康檢查",
      "description" : "彙整噪音作業特殊健康檢查各項結果之診斷報告，含聽力檢查、肺功能、心電圖與胸部X光。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-DiagnosticReport"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-LaborReportCode.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-LaborReportCode"
      },
      "name" : "勞動部通報報告代碼值集",
      "description" : "包含勞動部通報報告類別代碼之值集。（provisional，隨 CS-LaborReportCode 待官方確認）",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-labor-report-code.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-labor-report-code"
      },
      "name" : "勞動部通報報告代碼擴充",
      "description" : "標註此檢查結果通報至勞動部時所採用之報告大類代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-LaborReportCode.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-LaborReportCode"
      },
      "name" : "勞動部通報報告代碼系統",
      "description" : "勞工健檢結果通報勞動部（LABOR）系統時所使用之報告類別代碼。（**provisional**：本代碼系統為工作小組建議之本地代碼配置，**尚待勞動部職業安全衛生署確認官方代碼與定義（M-2）**；不得表述為已對接官方申報系統。）",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc002.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc002"
      },
      "name" : "勞工一般體格與健康檢查報告組成文件範例 (UC-002)",
      "description" : "整合王大同勞工一般健康檢查關聯項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-OccHealthCheck-Required.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-OccHealthCheck-Required"
      },
      "name" : "勞工健康檢查法定必驗項目值集（第一期草案）",
      "description" : "第一期法定必驗之勞工健康檢查項目草案子集，涵蓋附表九一般必驗生理量測與實驗室項目，以及噪音／鉛／粉塵三模組之核心必驗代碼。此為初版草案，範疇待附表九/十逐項法規盤點確認後修訂。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-employment-date.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-employment-date"
      },
      "name" : "受僱日期擴充",
      "description" : "記錄受檢勞工於事業單位之受僱日期。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-example-worker.html"
      }],
      "reference" : {
        "reference" : "Patient/example-worker"
      },
      "name" : "受檢勞工範例 - 王大同",
      "description" : "一名在電子公司化學處理課工作的勞工王大同之基本資料與雇主資訊。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Patient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Patient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Patient"
      },
      "name" : "受檢者 Profile",
      "description" : "本 Profile 用於描述接受健康檢查（含一般健檢、勞工健檢與成人預防保健）之受檢者，繼承自 TW Core Patient，並可選擴充記錄其所屬事業單位、受僱日期與所屬部門。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SocialHistory-Smoking.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SocialHistory-Smoking"
      },
      "name" : "吸菸歷史與狀態 Profile",
      "description" : "用於記錄勞工之吸菸狀態與吸菸量、戒菸時間等資訊，繼承自 TW Core Observation Smoking Status。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-SmokingStatus.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-SmokingStatus"
      },
      "name" : "吸菸狀態代碼系統",
      "description" : "勞工健檢生活習慣調查中之吸菸狀態分類。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-SmokingStatus.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-SmokingStatus"
      },
      "name" : "吸菸狀態值集",
      "description" : "包含吸菸狀態代碼的值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-smoking.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-smoking"
      },
      "name" : "吸菸狀態與菸量範例",
      "description" : "受檢勞工王大同的吸菸史（從未吸菸）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SocialHistory-Smoking"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-smoking-former.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-smoking-former"
      },
      "name" : "吸菸狀態與菸量範例 - 已戒菸",
      "description" : "受檢勞工之吸菸史：曾每日吸菸 20 支、菸齡 15 年，已戒菸 24 個月。用於示範 ext-smoking-quantity 與 ext-cessation-duration 之填法。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SocialHistory-Smoking"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-smoking-quantity.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-smoking-quantity"
      },
      "name" : "吸菸量及菸齡擴充",
      "description" : "記錄每日吸菸支數與吸菸年數。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SocialHistory-BetelNut.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SocialHistory-BetelNut"
      },
      "name" : "嚼檳榔歷史與狀態 Profile",
      "description" : "用於記錄勞工之嚼檳榔習慣與量化資料。本 Profile 基於 Observation 資源，採用與臺灣癌症登記短表實作指引 (TWCR_SF) 相同之元件架構及值集，以便進行跨系統之整合介接。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-betelnut.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-betelnut"
      },
      "name" : "嚼檳榔狀態與量化資料範例",
      "description" : "受檢勞工王大同的嚼檳榔習慣，每日嚼食 5 顆，嚼檳 10 年，目前已戒除 1 年（12個月）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SocialHistory-BetelNut"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-adult-preventive-care-questionnaire.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/adult-preventive-care-questionnaire"
      },
      "name" : "國健署成人預防保健生活習慣與既往病史問卷定義",
      "description" : "用於記錄國民健康署成人預防保健服務之健康行為、生活習慣與個人及家族病史自填問卷項目。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Questionnaire"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Practitioner.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Practitioner"
      },
      "name" : "執業/健檢醫護與服務人員 Profile",
      "description" : "本 Profile 用於描述實施勞工體格檢查、健康檢查或臨場健康服務之醫師、護理人員、職安人員等，繼承自 TW Core Practitioner。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-example-doctor.html"
      }],
      "reference" : {
        "reference" : "Practitioner/example-doctor"
      },
      "name" : "執業醫護人員範例 - 林職醫",
      "description" : "實施勞工體格及健康檢查評估並判定分級之林職醫師。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-example-nurse.html"
      }],
      "reference" : {
        "reference" : "Practitioner/example-nurse"
      },
      "name" : "執業醫護人員範例 - 陳健護",
      "description" : "執行生理量測（身高、體重、腰圍、血壓）與健康問診（吸菸、嚼檳榔、睡眠）之陳健護理師。用於示範 Observation.performer 之「人員」型態——與機構型態（example-hospital）對照。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Organization-Facility.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Organization-Facility"
      },
      "name" : "實施健康檢查之醫療機構 Profile",
      "description" : "本 Profile 用於描述實施勞工體格檢查、健康檢查或提供臨場健康服務之醫療機構，繼承自 TW Core Organization (醫院) 以精確反映醫療機構語義。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-example-hospital.html"
      }],
      "reference" : {
        "reference" : "Organization/example-hospital"
      },
      "name" : "實施健檢之醫療機構範例 - 航空醫務中心",
      "description" : "實施體格檢查及健康檢查之交通部民用航空局航空醫務中心。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Organization-Facility"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-lab-glucose.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-lab-glucose"
      },
      "name" : "實驗室檢驗範例 - 空腹血糖",
      "description" : "受檢勞工王大同的空腹血糖檢驗結果 (95 mg/dL)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-LabResult-General"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-lab-egfr-absent.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-lab-egfr-absent"
      },
      "name" : "實驗室檢驗缺值範例 - eGFR 未檢測（dataAbsentReason）",
      "description" : "受檢勞工王大同本次因故未完成腎絲球過濾率 (eGFR) 檢測。示範以 dataAbsentReason = not-performed 標明缺值原因，Observation 仍保留且合乎 twha-obs-1（value 或 dataAbsentReason 或 component 三者擇一）。eGFR 屬成健延伸項目，v3.0 Core 重構後歸 Extended，故綁 TWHA-LabResult-Special（VS-ExtendedDataset）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-LabResult-Special"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-occupation.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-occupation"
      },
      "name" : "工作經歷與職業別範例",
      "description" : "受檢勞工王大同之現任職業與行業別：電子零組件製造業之化學處理課作業員，2020 年 3 月到職迄今。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Occupation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-ECG.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-ECG"
      },
      "name" : "心電圖檢查 Profile",
      "description" : "用於記錄勞工心電圖檢查結果，通常於高溫作業特殊健檢中實施，繼承自 TW Core Observation ECG（v1.0.0 新增之心電圖專用 Profile）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-ecg.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-ecg"
      },
      "name" : "心電圖檢查結果範例",
      "description" : "受檢勞工王大同之十二導程心電圖檢查，判讀結果正常。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-ECG"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-QuestionnaireResponse-HT.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-QuestionnaireResponse-HT"
      },
      "name" : "成人預防保健問卷回覆 Profile",
      "description" : "用於記錄成人預防保健（國健署成人預防保健服務）之自覺症狀與生活習慣問卷回覆，繼承自 TW Core QuestionnaireResponse。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-adult-preventive-care-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/adult-preventive-care-response"
      },
      "name" : "成人預防保健問卷回覆實例",
      "description" : "王大同的成人預防保健生活習慣自填問卷回覆結果。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-QuestionnaireResponse-HT"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc005.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc005"
      },
      "name" : "成人預防保健檢查報告組成文件範例 (UC-005)",
      "description" : "整合王大同成人預防保健與生活習慣問卷項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-cessation-duration.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-cessation-duration"
      },
      "name" : "戒除時間（戒菸/戒檳榔月數）擴充",
      "description" : "記錄受檢者已戒菸或已戒檳榔的月數。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-past-condition.html"
      }],
      "reference" : {
        "reference" : "Condition/example-past-condition"
      },
      "name" : "既往病史範例 - 高血壓",
      "description" : "受檢勞工王大同的高血壓既往病史。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Condition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-OrganicSolventType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-OrganicSolventType"
      },
      "name" : "有機溶劑種類代碼系統",
      "description" : "特別危害健康作業中之有機溶劑種類（主要 7 種）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-OrganicSolventType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-OrganicSolventType"
      },
      "name" : "有機溶劑種類值集",
      "description" : "包含特別危害健康作業中之常見有機溶劑代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Group"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Group-example-group-workers.html"
      }],
      "reference" : {
        "reference" : "Group/example-group-workers"
      },
      "name" : "服務對象勞工群組範例",
      "description" : "大同電子現場化學製造部門之作業勞工群組。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-ExamType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-ExamType"
      },
      "name" : "檢查類型代碼系統",
      "description" : "勞工體格及健康檢查之類型，包含一般體格檢查、一般健康檢查、特殊體格檢查及特殊健康檢查。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-ExamType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-ExamType"
      },
      "name" : "檢查類型值集",
      "description" : "包含一般體格檢查、一般健康檢查、特殊體格檢查及特殊健康檢查之代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-exam-type.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-exam-type"
      },
      "name" : "檢查類型擴充",
      "description" : "標註該就醫事件（Encounter）是屬於一般體格、一般健康、特殊體格或特殊健康檢查。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-exposure-lead.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-exposure-lead"
      },
      "name" : "特別危害作業暴露史範例 - 鉛作業",
      "description" : "受檢勞工王大同從事鉛作業之暴露史，暴露年數 8 年，工作性質為電池極板熔鉛作業。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-WorkExposure"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-WorkExposure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-WorkExposure"
      },
      "name" : "特別危害健康作業危害因子暴露史 Profile",
      "description" : "用於記錄受檢勞工從事特別危害作業（如高溫、噪音、鉛、粉塵等）之暴露年數與詳細工作性質。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-HazardType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-HazardType"
      },
      "name" : "特別危害健康作業類別代碼系統",
      "description" : "勞工健康保護規則所定義之特別危害健康作業，歸併為 12 危害家族（家族層）。附表十（115.06.26 修正）逐號列舉之 35 項法定具名作業另以 CS-Appendix10Operation 表示，家族 ↔ 具名作業之對映見 ConceptMap Appendix10-to-HazardType。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-HazardType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-HazardType"
      },
      "name" : "特別危害健康作業類別值集",
      "description" : "包含 12 大類特別危害健康作業類別之代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-hazard-type.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-hazard-type"
      },
      "name" : "特別危害健康作業類別擴充",
      "description" : "標註該特殊體格或健康檢查所針對的危害作業種類（12大類）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-SpecificChemicalType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-SpecificChemicalType"
      },
      "name" : "特定化學物質種類代碼系統",
      "description" : "特別危害健康作業中之特定化學物質種類。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-SpecificChemicalType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-SpecificChemicalType"
      },
      "name" : "特定化學物質種類值集",
      "description" : "包含特別危害健康作業中之常見特定化學物質代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-LabResult-Special.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-LabResult-Special"
      },
      "name" : "特殊健檢實驗室檢驗 Profile",
      "description" : "用於記錄特別危害健康作業勞工之特殊實驗室檢驗結果（如血中鉛等），繼承自 TW Core Lab Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc003.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc003"
      },
      "name" : "特殊危害健康作業檢查報告組成文件範例 (UC-003)",
      "description" : "整合王大同噪音/鉛/粉塵特殊危害作業檢查項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-physical.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-physical"
      },
      "name" : "理學檢查結果範例",
      "description" : "受檢勞工王大同各系統理學檢查結果（正常）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-PhysicalExam"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SocialHistory-Sleep.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SocialHistory-Sleep"
      },
      "name" : "睡眠狀況 Profile",
      "description" : "用於記錄勞工之平均每日睡眠時間（以小時計）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-sleep.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-sleep"
      },
      "name" : "睡眠狀況測量範例",
      "description" : "受檢勞工王大同的平均每日睡眠時間 (7 小時)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SocialHistory-Sleep"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SDOH-QuestionnaireResponse.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SDOH-QuestionnaireResponse"
      },
      "name" : "社會決定因素 (SDOH) 問卷回覆 Profile",
      "description" : "用於記錄受檢者之社會決定因素問卷結果（基於精簡版 PRAPARE 社會風險問卷），繼承自 TW Core QuestionnaireResponse。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-twha-sdoh-questionnaire.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/twha-sdoh-questionnaire"
      },
      "name" : "精簡版 PRAPARE 社會風險問卷定義",
      "description" : "包含教育程度、就業狀態、居住環境安全、主要照顧壓力與經濟困難等 5 個核心社會決定因素 (SDOH) 欄位之問卷。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Questionnaire"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Composition-EmergencySummary.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Composition-EmergencySummary"
      },
      "name" : "職業健康急診友善摘要 Composition Profile",
      "description" : "職業健康急診友善摘要（Occupational Health Emergency Summary）。當勞工於急診就醫時，供急診醫師快速掌握其特別危害作業暴露史、關鍵生命徵象與檢驗值、以及健康管理分級。以 Composition 承載，將既有之暴露史（TWHA-WorkExposure）、生命徵象、CBC／肝腎功能等關鍵檢驗與總評分級以 section.entry 引用。\n\n**定位**：本 Profile 為**按需產生之臨床摘要原型（prototype）**，屬工作小組建議方案，**非正式交換要求**；俟臨床測試與回饋後再確認其範圍與必填欄位。\n\n**使用限制（負向表列，實作與臨床使用時必須遵守）**：\n1. **本摘要不取代急診臨床評估**：所載資料為既有健檢紀錄之彙整，不構成診斷或處置建議，急診決策仍應以當下臨床評估為準。\n2. **舊值必須顯示資料日期與來源機構**：所引用之每筆檢驗／量測結果，均須可辨識其 `effectiveDateTime` 與 `performer`／來源機構；未標示日期與來源之數值不得呈現。\n3. **無資料不等於無暴露**：本摘要未列出某項危害暴露，僅表示系統中無相關紀錄，**不得推論該勞工未曾暴露**；必要時仍應詢問病史。\n4. **受檢者自述與機構驗證資料必須可區分**：以問卷／自述取得之資訊（如 QuestionnaireResponse）與經醫療機構檢驗驗證之結果，須於呈現時明確區分，不得混同陳列。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-emergency-summary.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-emergency-summary"
      },
      "name" : "職業健康急診友善摘要範例 (UC-007)",
      "description" : "整合王大同鉛作業暴露史、生命徵象與關鍵檢驗值之急診友善摘要，供急診醫師快速掌握其職業暴露背景。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition-EmergencySummary"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-VitalSigns.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-VitalSigns"
      },
      "name" : "職業健檢生命徵象 Profile",
      "description" : "用於記錄勞工身高、體重、腰圍等基本生理特徵，繼承自 TW Core Vital Signs。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-TWHAVitalSigns.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-TWHAVitalSigns"
      },
      "name" : "職業健檢生命徵象項目值集",
      "description" : "包含身高、體重、腰圍及血壓等生理測量項目之 LOINC 代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-HearingTest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-HearingTest"
      },
      "name" : "聽力檢查 Profile",
      "description" : "用於記錄勞工純音聽力測試結果，依左右耳及頻率（0.5/1/2/3/4/6/8 kHz）分切片記錄。繼承自 TW Core Observation Clinical Result。v1.1 修正：更正並補齊純音氣導聽閾 LOINC 代碼（原 v3 之頻率×耳別代碼多處錯置，且缺 3/6/8 kHz），使各切片代碼與 LOINC「Pure tone threshold audiometry panel」(89015-2) 之成員一致，符合《勞工健康保護規則》附表十噪音作業之 0.5–8 kHz 全頻率要求。\n\n**交換規則（回應委員意見）**：\n1. **須保留原始 panel／component 代碼**：若來源系統採 `21104-5` 系列等變異碼，交換時**應同時保留原始代碼**（如置於 `code.coding` 之另一 coding），**不得僅存歸一後之代碼**，以維持可追溯性。\n2. **panel 層 mapping 不等於 component 層等價**：ConceptMap 現僅建立 panel 對 panel 之對應；**各頻率 component 之對應尚未建立（mapping unavailable）**，不得逕行推論等價。\n3. **聽閾單位**：以 UCUM `dB` 表達（臨床意義為 dB HL，依 ISO 1999 判讀）。\n4. **特殊情形不得以一般數值表達**：「未測」「無反應」「超出儀器上限」等情形，**應以 `dataAbsentReason` 或明確代碼表達**，不得填入 0、999 等假數值，亦不得省略該 component。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-hearing.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-hearing"
      },
      "name" : "聽力檢查結果範例",
      "description" : "受檢勞工王大同的純音聽力測試結果（左右耳 0.5–8 kHz 各頻率聽力閾值均在正常範圍 ≤25 dB）。v1.1 更新：使用正確 Panel code 89015-2 及更正／補齊之頻率×耳別切片（0.5/1/2/3/4/6/8 kHz）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-HearingTest"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-PulmonaryFunction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-PulmonaryFunction"
      },
      "name" : "肺功能檢查 Profile",
      "description" : "用於記錄勞工肺功能檢查結果（主要包括 FVC, FEV1, FEV1/FVC），繼承自 TW Core Observation Clinical Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-pulmonary.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-pulmonary"
      },
      "name" : "肺功能檢查結果範例",
      "description" : "受檢勞工王大同的肺功能檢查結果（FVC = 4.2 L, FEV1 = 3.5 L, FEV1/FVC = 83.3%）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-PulmonaryFunction"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-PulmonaryFunction.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-PulmonaryFunction"
      },
      "name" : "肺功能檢查項目值集",
      "description" : "包含常用之肺功能檢查（如 FVC, FEV1, FEV1/FVC 等）的 LOINC 代碼，以供肺功能檢查 Profile 使用。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-waist.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-waist"
      },
      "name" : "腰圍測量結果範例",
      "description" : "受檢勞工王大同的腰圍測量結果 (82 cm)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VitalSigns"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Encounter-Service.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Encounter-Service"
      },
      "name" : "臨場健康服務事件 Profile",
      "description" : "本 Profile 用於描述醫護團隊到事業單位提供臨場健康服務之就醫/諮詢事件（對應附表八）。\n\n**語意界定（回應委員意見）**：本資源表達「**一次臨場服務事件**」。`serviceProvider` 為提供服務之醫療機構；受服務之事業單位以 `extension[employerInfo]` 表達，**不置於 subject**。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Task-ServiceTask.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Task-ServiceTask"
      },
      "name" : "臨場健康服務建議與改善任務 Profile",
      "description" : "用於記錄臨場服務中針對發現問題所提出之改善建議措施，以及追蹤前次改善事項之落實情形（對應附表八）。\n\n**for／focus／owner 語意界定（回應委員意見）**：本資源表達「**後續改善工作**」。`focus` 指向所依據之現場發現（ServiceFinding）；`owner` 為負責執行改善之事業單位；若改善事項係針對特定勞工（如個別配工調整），以 `for` 表達該 Patient。**事業單位以 `owner` 表達，不置於 `for`。**",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Observation-ServiceFinding.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Observation-ServiceFinding"
      },
      "name" : "臨場健康服務發現問題/風險 Profile",
      "description" : "用於記錄臨場健康服務中發現之作業場所問題、健康危害或風險（附表八）。\n\n**subject／focus 語意界定（回應委員意見）**：本資源記錄「**現場發現**」。所發現問題**所屬之事業單位以 `focus` 表達**，不置於 `subject`；若該發現係針對特定勞工個人（如個別健康異常），則 `subject` 為該 Patient。事業單位不作為 `subject`。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-ServiceActivityType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-ServiceActivityType"
      },
      "name" : "臨場健康服務辦理事項代碼系統",
      "description" : "附表八中醫護人員辦理之臨場健康服務項目活動類別代碼系統。（**provisional**：本地代碼配置，尚待勞動部職業安全衛生署確認官方代碼與定義（M-2）。另因 SNOMED 現無適切之職業健康諮詢 procedure 代碼，改善建議諮詢暫以本代碼系統承載，該用法列為本地碼治理事項。）",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-ServiceActivityType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-ServiceActivityType"
      },
      "name" : "臨場健康服務辦理事項值集",
      "description" : "包含臨場健康服務項目活動類別代碼之值集。（provisional，隨 CS-ServiceActivityType 待官方確認）",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-example-encounter-service.html"
      }],
      "reference" : {
        "reference" : "Encounter/example-encounter-service"
      },
      "name" : "臨場服務事件範例",
      "description" : "林職醫師與護理師於115年6月10日前往大同電子股份有限公司進行現場臨場服務。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Encounter-Service"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Procedure-ServiceActivity.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Procedure-ServiceActivity"
      },
      "name" : "臨場服務執行活動項目 Profile",
      "description" : "用於記錄醫護人員在臨場健康服務中實際辦理之活動項目（對應附表八之臨場健康服務執行情形），繼承自 TW Core Procedure。\n\n**subject 選用規則（回應委員意見）**：**個人健康指導／個案追蹤 → `subject` = Patient**；**群體衛教／全廠宣導 → `subject` = Group**。**事業單位不作為 `subject`**，改以 `extension[employerInfo]` 表達所屬事業單位。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-example-procedure-activity.html"
      }],
      "reference" : {
        "reference" : "Procedure/example-procedure-activity"
      },
      "name" : "臨場服務執行活動項目範例",
      "description" : "在臨場服務中辦理「健康檢查結果分析」的執行紀錄。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Procedure-ServiceActivity"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-example-service-task.html"
      }],
      "reference" : {
        "reference" : "Task/example-service-task"
      },
      "name" : "臨場服務建議改善措施與追蹤任務範例",
      "description" : "林職醫師針對現場發現問題提出之改善建議，交由雇主大同電子執行改善。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Task-ServiceTask"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-example-service-finding.html"
      }],
      "reference" : {
        "reference" : "Observation/example-service-finding"
      },
      "name" : "臨場服務現場發現問題範例",
      "description" : "臨場服務中發現作業現場危害因子及問題。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Observation-ServiceFinding"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-example-composition-service.html"
      }],
      "reference" : {
        "reference" : "Composition/example-composition-service"
      },
      "name" : "臨場服務紀錄組成文件範例 (UC-006)",
      "description" : "整合大同電子 115年6月份臨場服務紀錄（附表八）的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition-ServiceRecord"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-QuestionnaireResponse.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-QuestionnaireResponse"
      },
      "name" : "自覺症狀問卷回覆 Profile",
      "description" : "用於記錄勞工所填寫之自覺症狀問卷結果，必須關聯至受檢勞工，繼承自 TW Core QuestionnaireResponse。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-example-symptoms-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/example-symptoms-response"
      },
      "name" : "自覺症狀問卷回覆範例",
      "description" : "受檢勞工王大同的自覺症狀問卷填寫結果。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-QuestionnaireResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-example-questionnaire.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/example-questionnaire"
      },
      "name" : "自覺症狀問卷定義範例",
      "description" : "自覺症狀調查問卷結構定義。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Questionnaire"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc004.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc004"
      },
      "name" : "自費健康檢查與進階影像鏡檢報告組成文件範例 (UC-004)",
      "description" : "整合王大同自費影像造影與內視鏡檢查項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-mammo.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-mammo"
      },
      "name" : "自費健檢項目 - 乳房攝影",
      "description" : "自費健檢中乳房攝影檢查的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-pet.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-pet"
      },
      "name" : "自費健檢項目 - 全身正子造影",
      "description" : "自費健檢中全身正子造影 (FDG PET/CT) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-endoscopy-colon.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-endoscopy-colon"
      },
      "name" : "自費健檢項目 - 大腸鏡檢查",
      "description" : "自費健檢中下消化道大腸鏡鏡檢 (Colonoscopy) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-cta.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-cta"
      },
      "name" : "自費健檢項目 - 心臟冠狀動脈電腦斷層血管攝影",
      "description" : "自費健檢中心臟冠狀動脈電腦斷層血管攝影 (Cardiac CTA) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-lung-ct.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-lung-ct"
      },
      "name" : "自費健檢項目 - 肺部低劑量電腦斷層",
      "description" : "自費健檢中肺部低劑量電腦斷層 (LDCT) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-endoscopy-egd.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-endoscopy-egd"
      },
      "name" : "自費健檢項目 - 胃鏡檢查",
      "description" : "自費健檢中上消化道胃鏡鏡檢 (EGD) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-brain-mri.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-brain-mri"
      },
      "name" : "自費健檢項目 - 腦部核磁共振造影",
      "description" : "自費健檢中腦部核磁共振造影 (Brain MRI) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-bloodpressure.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-bloodpressure"
      },
      "name" : "血壓測量結果範例",
      "description" : "受檢勞工王大同的血壓測量結果 (120/80 mmHg)，繼承自 TW Core Blood Pressure。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-vision.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-vision"
      },
      "name" : "視力及辨色力檢查結果範例",
      "description" : "受檢勞工王大同的視力（裸視左/右 1.0）及辨色力（正常）檢查結果。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VisionTest"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-VisionTest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-VisionTest"
      },
      "name" : "視力與辨色力檢查 Profile",
      "description" : "用於記錄勞工眼部檢查結果，包含左右眼裸視/矯正視力及辨色力項目，繼承自 TW Core Observation Clinical Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-PhysicalExamSystems.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-PhysicalExamSystems"
      },
      "name" : "身體檢查系統部位代碼系統",
      "description" : "附表十一理學檢查中所涉及之身體系統部位分類。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-PhysicalExamSystems.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-PhysicalExamSystems"
      },
      "name" : "身體檢查系統部位值集",
      "description" : "包含理學檢查中各系統部位代碼之值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-PhysicalExam.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-PhysicalExam"
      },
      "name" : "身體理學檢查 Profile",
      "description" : "用於記錄勞工身體各系統（頭頸部、呼吸、心血管、消化、神經、肌肉骨骼、皮膚）之理學檢查結果，繼承自 TW Core Observation Clinical Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-bmi.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-bmi"
      },
      "name" : "身體質量指數 (BMI) 測量結果範例",
      "description" : "受檢勞工王大同的身體質量指數 (BMI) 測量結果 (22.86 kg/m2)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VitalSigns"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-height.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-height"
      },
      "name" : "身高測量結果範例",
      "description" : "受檢勞工王大同的身高測量結果 (175 cm)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VitalSigns"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-example-servicerequest-followup.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/example-servicerequest-followup"
      },
      "name" : "追蹤檢查要求範例 - 三個月後聽力複檢",
      "description" : "醫師針對第四級健康管理之勞工王大同開立之追蹤檢查要求：三個月後實施純音聽力檢查複檢。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-ServiceRequest"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-FitnessForWork.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-FitnessForWork"
      },
      "name" : "適性配工建議代碼系統",
      "description" : "第四級管理中，醫師針對受檢勞工提出之適性配工或變更作業內容建議。（**provisional**：本代碼系統為工作小組建議之本地代碼配置，**尚待勞動部職業安全衛生署確認官方代碼與定義（M-2）**；不得表述為已對接官方申報系統。）",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-FitnessForWork.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-FitnessForWork"
      },
      "name" : "適性配工建議值集",
      "description" : "包含適性配工或工作調整建議代碼之值集。（provisional，隨 CS-FitnessForWork 待官方確認）",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-fitness-for-work.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-fitness-for-work"
      },
      "name" : "適性配工建議項目擴充",
      "description" : "用於 CarePlan 中標註具體的適性配工或變更作業場所等建議項目。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-example-careplan-fitness.html"
      }],
      "reference" : {
        "reference" : "CarePlan/example-careplan-fitness"
      },
      "name" : "適性配工計畫範例 - 第四級管理之工作調整",
      "description" : "針對判定為第四級健康管理之勞工王大同，由職業醫學科醫師與事業單位共同制定之適性配工計畫：變更工作場所並縮短噪音暴露時間。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-CarePlan"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-department.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-department"
      },
      "name" : "部門/課別擴充",
      "description" : "記錄受檢勞工於事業單位中所屬之部門、課別或課室名稱。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClinicalImpression"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClinicalImpression-example-clinical-impression.html"
      }],
      "reference" : {
        "reference" : "ClinicalImpression/example-clinical-impression"
      },
      "name" : "醫師臨床總評與分級範例",
      "description" : "林職醫師針對王大同的健康檢查結果進行之總評，判定為第一級健康管理（正常）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-ClinicalImpression"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-Appendix9-RequiredSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-Appendix9-RequiredSet"
      },
      "name" : "附表九 一般健康檢查法定應執行項目值集",
      "description" : "《勞工健康保護規則》附表九所列一般體格／健康檢查之法定應執行**檢驗與量測**項目（以健康檢查欄為準，含 LDL-C）。非檢驗項目（作業經歷、既往病史、生活習慣、自覺症狀、身體各系統理學檢查）以 TWHA-Occupation／TWHA-Condition／SocialHistory／TWHA-PhysicalExam 承載，不列為本值集成員。用於法定完整性稽核，非 profile 之 element binding。所有代碼均取自已通過術語稽核之既有內容。⚠️ 紅血球數（789-8）與 MCV（787-2）係 115.06.26 修正新增；repo 內附表九 PDF 為修正前版本，該二項無 repo 內原文可逐項核對，見未決事項 M-11。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-Appendix10-to-HazardType.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/Appendix10-to-HazardType"
      },
      "name" : "附表十 35 項法定作業 對 12 危害家族 對照",
      "description" : "將 CS-Appendix10Operation（附表十 35 項具名作業）對映至 CS-HazardType（12 危害家族）。每一具名作業（source）相對於其對應之危害家族（target）在語意上較窄，故 equivalence = narrower（家族涵蓋範圍較廣）。供接收端由法定作業編號歸併至危害家族，回應審查意見之逐號可追溯性需求。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-Appendix10-Noise-RequiredSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-Appendix10-Noise-RequiredSet"
      },
      "name" : "附表十 噪音作業 專屬應執行項目值集",
      "description" : "附表十第 2 項噪音作業之家族專屬檢查項目（純音聽力）。共同一般項目見 VS-Appendix9-RequiredSet。用於完整性稽核，非 element binding。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-Appendix10-OrganicSolvent-RequiredSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-Appendix10-OrganicSolvent-RequiredSet"
      },
      "name" : "附表十 有機溶劑作業 專屬應執行項目值集",
      "description" : "附表十第 7–12、33–35 項有機溶劑類作業之家族專屬檢查項目：各作業之尿中生物偵測代謝物與肝功能。⚠️ 附表十本文對此類作業僅列肝功能（ALT／γ-GT，二硫化碳另含心電圖）；各尿中代謝物係職安署特殊健檢細項生物偵測之口徑（非附表十逐字項目），該範疇界定為未決事項 M-11。附表十號別 → 代謝物之對應見 special-exam.md 涵蓋表。共同一般項目見 VS-Appendix9-RequiredSet。用於完整性稽核，非 element binding。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-Appendix10-RequiredSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-Appendix10-RequiredSet"
      },
      "name" : "附表十 特殊健康檢查應執行項目值集（已落地家族）",
      "description" : "附表十特別危害健康作業之家族專屬應執行項目 grouping 值集。**目前僅含已通過術語稽核之四家族**（噪音／鉛／粉塵／有機溶劑）；其餘八家族之專屬代碼待 JOB-01 臨床確認後擴充（見 special-exam.md 涵蓋表與未決事項 M-8）。任一家族之完整情境需求 ＝ 本 grouping 對應子集 ∪ VS-Appendix9-RequiredSet。用於完整性稽核，非 element binding。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-Appendix10-Dust-RequiredSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-Appendix10-Dust-RequiredSet"
      },
      "name" : "附表十 粉塵作業 專屬應執行項目值集",
      "description" : "附表十第 23 項粉塵作業之家族專屬檢查項目（胸部 X 光與肺功能）。共同一般項目見 VS-Appendix9-RequiredSet。用於完整性稽核，非 element binding。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-Appendix10-Lead-RequiredSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-Appendix10-Lead-RequiredSet"
      },
      "name" : "附表十 鉛作業 專屬應執行項目值集",
      "description" : "附表十第 5 項鉛作業之家族專屬檢查項目。附表十本文僅列血中鉛；尿中鉛／共聚卟啉／δ-ALA 係職安署特殊健檢細項生物偵測之口徑（非附表十逐字項目），該範疇界定為未決事項 M-11。共同一般項目見 VS-Appendix9-RequiredSet。用於完整性稽核，非 element binding。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-Appendix10-Operation.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-Appendix10-Operation"
      },
      "name" : "附表十特別危害健康作業值集（35 項）",
      "description" : "包含《勞工健康保護規則》附表十 35 項法定具名作業之代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-Appendix10Operation.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-Appendix10Operation"
      },
      "name" : "附表十特別危害健康作業具名代碼系統",
      "description" : "《勞工健康保護規則》附表十（115.06.26 修正）逐號列舉之 35 項特別危害健康作業具名代碼。本代碼系統為「具名作業層」，與 CS-HazardType（12 危害家族層）以 ConceptMap Appendix10-to-HazardType 對映。編號 33/34/35（苯乙烯、甲苯、二甲苯）為 115.06.26 修正新增，狀態為 **draft**：其施行日期與既有勞工銜接安排尚待勞動部職業安全衛生署確認，本 IG 之檢查項目與代碼配置屬暫定。過渡期以本 CodeSystem 之 version（法規版本）表達，個案資料僅記錄實際檢查日期與所採規範版本，不另加自訂旗標。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-example-employer.html"
      }],
      "reference" : {
        "reference" : "Organization/example-employer"
      },
      "name" : "雇主事業單位範例 - 大同電子",
      "description" : "受檢勞工王大同所屬之事業單位組織資料。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Organization-Employer"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-employer-info.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-employer-info"
      },
      "name" : "雇主事業單位資訊擴充",
      "description" : "關聯受檢勞工所屬之事業單位組織資料，或臨場服務事件/活動所針對之事業單位。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Composition-EmployerSummary.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Composition-EmployerSummary"
      },
      "name" : "雇主端健康管理摘要 Composition Profile",
      "description" : "雇主端／職安人員健康管理摘要（Employer Health Management Summary）。落實 security.md 之角色存取控制：雇主僅得取得**健康管理分級、適性配工建議與臨場服務發現**，**不得**取得檢驗數值。以 **closed section slicing** 結構性保證本摘要不含檢驗／影像 section；各 section 之 entry 以 profile 限定，檢驗類 Observation／DiagnosticReport 無從置入。此為欄位級隔離之可驗證機制，取代僅以文字宣示之做法（SMART scope 難達欄位級隔離，見 security.md §2）。存取控制之實作機制（scope／Consent／端點）屬平台端決定，見未決事項 M-10。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-example-composition-employer-summary.html"
      }],
      "reference" : {
        "reference" : "Composition/example-composition-employer-summary"
      },
      "name" : "雇主端健康管理摘要範例",
      "description" : "提供予事業單位／職安人員之健康管理摘要：僅含王大同之健康管理分級、適性配工建議與臨場服務發現，**不含任何檢驗數值**。與醫護端之急診摘要（composition-emergency-summary，含關鍵檢驗值 section）對照，即見雇主端封包之欄位級隔離。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition-EmployerSummary"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SocialHistory-Alcohol.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SocialHistory-Alcohol"
      },
      "name" : "飲酒歷史與狀態 Profile",
      "description" : "用於記錄勞工之飲酒習慣歷史與狀態。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-alcohol.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-alcohol"
      },
      "name" : "飲酒歷史與狀態範例",
      "description" : "受檢勞工王大同之飲酒習慣：目前有飲酒習慣。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SocialHistory-Alcohol"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-weight.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-weight"
      },
      "name" : "體重測量結果範例",
      "description" : "受檢勞工王大同的體重測量結果 (70 kg)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VitalSigns"
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "adult-preventive-care.html"
        }],
        "nameUrl" : "adult-preventive-care.html",
        "title" : "Adult Preventive Care",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "background.html"
        }],
        "nameUrl" : "background.html",
        "title" : "Background",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "conformance.html"
        }],
        "nameUrl" : "conformance.html",
        "title" : "Conformance",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "datamodel.html"
        }],
        "nameUrl" : "datamodel.html",
        "title" : "Datamodel",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "general-exam.html"
        }],
        "nameUrl" : "general-exam.html",
        "title" : "General Exam",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "health-management.html"
        }],
        "nameUrl" : "health-management.html",
        "title" : "Health Management",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "history.html"
        }],
        "nameUrl" : "history.html",
        "title" : "History",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "ip-statements.html"
        }],
        "nameUrl" : "ip-statements.html",
        "title" : "Ip Statements",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "open-issues.html"
        }],
        "nameUrl" : "open-issues.html",
        "title" : "Open Issues",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "security.html"
        }],
        "nameUrl" : "security.html",
        "title" : "Security",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "service-record.html"
        }],
        "nameUrl" : "service-record.html",
        "title" : "Service Record",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "special-exam.html"
        }],
        "nameUrl" : "special-exam.html",
        "title" : "Special Exam",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "terminology.html"
        }],
        "nameUrl" : "terminology.html",
        "title" : "Terminology",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "usecases.html"
        }],
        "nameUrl" : "usecases.html",
        "title" : "Usecases",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
