# 特殊危害健康作業檢查報告組成文件範例 (UC-003) - 臺灣勞工健康檢查交換實作指引 (Taiwan Labor Health Examination Exchange FHIR IG, TWHA IG) v0.10.4

## 範例 Composition: 特殊危害健康作業檢查報告組成文件範例 (UC-003)

Profile: [健康檢查健檢報告組成結構 Profile](StructureDefinition-TWHA-Composition.md)

**status**: Final

**type**: Laboratory report

**date**: 2026-06-12 11:45:00+0800

**author**: [Practitioner 林職醫(official)](Practitioner-example-doctor.md)

**title**: 特殊危害健康作業檢查報告



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "composition-uc003",
  "meta" : {
    "profile" : ["https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"]
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "11502-2",
      "display" : "Laboratory report"
    }]
  },
  "subject" : {
    "reference" : "Patient/example-worker"
  },
  "date" : "2026-06-12T11:45:00+08:00",
  "author" : [{
    "reference" : "Practitioner/example-doctor"
  }],
  "title" : "特殊危害健康作業檢查報告",
  "section" : [{
    "title" : "基本資料與行政資訊",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "51847-2"
      }]
    },
    "entry" : [{
      "reference" : "Patient/example-worker"
    },
    {
      "reference" : "Encounter/example-encounter-special"
    }]
  },
  {
    "title" : "醫師總評、分級與建議",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "51848-0"
      }]
    },
    "entry" : [{
      "reference" : "ClinicalImpression/example-clinical-impression"
    },
    {
      "reference" : "Observation/obs-health-mgmt-level"
    },
    {
      "reference" : "CarePlan/example-careplan-fitness"
    },
    {
      "reference" : "ServiceRequest/example-servicerequest-followup"
    }]
  },
  {
    "title" : "作業經歷",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "11341-5"
      }]
    },
    "entry" : [{
      "reference" : "Observation/obs-occupation"
    }]
  },
  {
    "title" : "生活習慣",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "11338-1"
      }]
    },
    "entry" : [{
      "reference" : "Observation/obs-alcohol"
    },
    {
      "reference" : "Observation/obs-smoking-former"
    }]
  },
  {
    "title" : "理學檢查",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "29545-1"
      }]
    },
    "entry" : [{
      "reference" : "Observation/obs-hearing"
    }]
  },
  {
    "title" : "檢驗與影像檢查",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "30954-2"
      }]
    },
    "entry" : [{
      "reference" : "Observation/obs-pulmonary"
    },
    {
      "reference" : "Observation/obs-ecg"
    },
    {
      "reference" : "ImagingStudy/example-imaging-chest-xray"
    },
    {
      "reference" : "DiagnosticReport/example-diagnostic-report"
    }]
  }]
}

```
