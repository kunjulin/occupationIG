# 健康檢查核心檢驗項目值集（主管機關最小上傳集之檢驗子集） - 臺灣勞工健康檢查交換實作指引 (Taiwan Labor Health Examination Exchange FHIR IG, TWHA IG) v0.1.0

## ValueSet: 健康檢查核心檢驗項目值集（主管機關最小上傳集之檢驗子集） 

 
Core 之檢驗子集（主管機關（國健署）最小共通上傳集之 Observation.code 綁定值集，綁定強度 extensible）。僅收錄 Core 之 10 檢驗項 preferred code 及其 acceptable 變異碼；生理量測（身高/體重/腰圍/血壓）碼分屬 VS-TWHAVitalSigns、社會史（吸菸/嚼檳）碼分屬 SocialHistory profile。Core 全集（21 列）之群組見 VS-CoreUploadSet。acceptable→preferred 歸一見 ConceptMap TWHealthCheckLaboratoryMap。 

 **References** 

* Included into [VS_CoreUploadSet](ValueSet-VS-CoreUploadSet.md)
* [一般健檢實驗室檢驗 Profile](StructureDefinition-TWHA-LabResult-General.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (not supported by Publication Tooling)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "VS-CoreDataset",
  "url" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-CoreDataset",
  "version" : "0.1.0",
  "name" : "VS_CoreDataset",
  "title" : "健康檢查核心檢驗項目值集（主管機關最小上傳集之檢驗子集）",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-24T13:54:16+08:00",
  "publisher" : "衛生福利部次世代數位醫療平臺專案辦公室 & 長庚醫療財團法人長庚紀念醫院",
  "contact" : [{
    "name" : "衛生福利部次世代數位醫療平臺專案辦公室 & 長庚醫療財團法人長庚紀念醫院",
    "telecom" : [{
      "system" : "url",
      "value" : "https://twcore.mohw.gov.tw/twregistry/"
    }]
  },
  {
    "name" : "衛生福利部次世代數位醫療平臺專案辦公室",
    "telecom" : [{
      "system" : "url",
      "value" : "https://twcore.mohw.gov.tw/twregistry/"
    }]
  }],
  "description" : "Core 之檢驗子集（主管機關（國健署）最小共通上傳集之 Observation.code 綁定值集，綁定強度 extensible）。僅收錄 Core 之 10 檢驗項 preferred code 及其 acceptable 變異碼；生理量測（身高/體重/腰圍/血壓）碼分屬 VS-TWHAVitalSigns、社會史（吸菸/嚼檳）碼分屬 SocialHistory profile。Core 全集（21 列）之群組見 VS-CoreUploadSet。acceptable→preferred 歸一見 ConceptMap TWHealthCheckLaboratoryMap。",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "2093-3",
        "display" : "Cholesterol [Mass/volume] in Serum or Plasma"
      },
      {
        "code" : "35200-5",
        "display" : "Cholesterol [Mass/volume] in Blood"
      },
      {
        "code" : "1558-6",
        "display" : "Fasting Glucose [Mass/volume] in Serum or Plasma"
      },
      {
        "code" : "2339-0",
        "display" : "Glucose [Mass/volume] in Blood"
      },
      {
        "code" : "2345-7",
        "display" : "Glucose [Mass/volume] in Serum or Plasma -- post fasting"
      },
      {
        "code" : "2571-8",
        "display" : "Triglyceride [Mass/volume] in Serum or Plasma"
      },
      {
        "code" : "3043-7",
        "display" : "Triglyceride [Mass/volume] in Blood"
      },
      {
        "code" : "2085-9",
        "display" : "Cholesterol in HDL [Mass/volume] in Serum or Plasma"
      },
      {
        "code" : "3048-6",
        "display" : "Cholesterol in HDL [Mass/volume] in Blood"
      },
      {
        "code" : "2089-1",
        "display" : "Cholesterol in LDL [Mass/volume] in Serum or Plasma by Direct assay"
      },
      {
        "code" : "13457-7",
        "display" : "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation"
      },
      {
        "code" : "18262-6",
        "display" : "Cholesterol in LDL [Mass/volume] in Serum or Plasma by Direct assay"
      },
      {
        "code" : "2160-0",
        "display" : "Creatinine [Mass/volume] in Serum or Plasma"
      },
      {
        "code" : "38483-4",
        "display" : "Creatinine [Mass/volume] in Blood"
      },
      {
        "code" : "2888-6",
        "display" : "Protein [Mass/volume] in Urine"
      },
      {
        "code" : "5804-0",
        "display" : "Protein [Presence] in Urine by Test strip"
      },
      {
        "code" : "57735-3",
        "display" : "Protein [Presence] in Urine by Test strip"
      },
      {
        "code" : "5196-1",
        "display" : "Hepatitis B virus surface Ag [Presence] in Serum"
      },
      {
        "code" : "22326-3",
        "display" : "Hepatitis B virus surface Ag [Presence] in Serum or Plasma"
      },
      {
        "code" : "63557-3",
        "display" : "Hepatitis B virus surface Ag [Presence] in Serum or Plasma by Immunoassay"
      },
      {
        "code" : "13955-0",
        "display" : "Hepatitis C virus Ab [Presence] in Serum or Plasma"
      },
      {
        "code" : "47365-2",
        "display" : "Hepatitis C virus Ab [Presence] in Blood"
      }]
    }]
  }
}

```
