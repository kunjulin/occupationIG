# Resource 臺灣勞工健康檢查交換實作指引 (Taiwan Labor Health Examination Exchange FHIR IG, TWHA IG)



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "mohw.tw.twha",
  "language" : "en",
  "url" : "https://twcore.mohw.gov.tw/ig/twha/ImplementationGuide/mohw.tw.twha",
  "version" : "0.1.0",
  "name" : "TWHAIG",
  "title" : "臺灣勞工健康檢查交換實作指引 (Taiwan Labor Health Examination Exchange FHIR IG, TWHA IG)",
  "status" : "active",
  "date" : "2026-07-24T13:54:16+08:00",
  "publisher" : "衛生福利部次世代數位醫療平臺專案辦公室 & 長庚醫療財團法人長庚紀念醫院",
  "contact" : [{
    "name" : "衛生福利部次世代數位醫療平臺專案辦公室 & 長庚醫療財團法人長庚紀念醫院",
    "telecom" : [{
      "system" : "url",
      "value" : "https://twcore.mohw.gov.tw/twregistry/"
    }]
  },
  {
    "name" : "衛生福利部次世代數位醫療平臺專案辦公室",
    "telecom" : [{
      "system" : "url",
      "value" : "https://twcore.mohw.gov.tw/twregistry/"
    }]
  }],
  "description" : "以勞工健康檢查為核心之 FHIR 資料交換標準，繼承臺灣核心實作指引 (TW Core IG)，並可向特殊職類與一般健康檢查／成人預防保健需求擴充。",
  "packageId" : "mohw.tw.twha",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.2.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "tw_gov_mohw_twcore",
    "uri" : "https://twcore.mohw.gov.tw/ig/twcore/ImplementationGuide/tw.gov.mohw.twcore",
    "packageId" : "tw.gov.mohw.twcore",
    "version" : "1.0.0"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2026+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "STU1"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewAmount-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewBeh-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewQuit-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewYear-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-ObserBeh-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewAmount-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewBeh-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewQuit-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewYear-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-CoreDataset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-ExtendedDataset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-OccHealthCheck-Required"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-PulmonaryFunction"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-TWHAVitalSigns"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-UnfitDiseases"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2026+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "STU1"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewAmount-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewBeh-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewQuit-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-BetNutChewYear-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/CodeSystem/sf-ObserBeh-codesystem"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewAmount-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewBeh-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewQuit-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "https://hapi.fhir.tw/fhir/ValueSet/sf-BetNutChewYear-valueset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-CoreDataset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-ExtendedDataset"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-OccHealthCheck-Required"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-PulmonaryFunction"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-TWHAVitalSigns"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-validate"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/ValueSet/VS-UnfitDiseases"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://twcore.mohw.gov.tw/ig/twha/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-BetNutChewBeh-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-BetNutChewBeh-codesystem"
      },
      "name" : "Betel Nut Chewing Behavior Code System",
      "description" : "Betel Nut Chewing Behavior Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-sdoh-questionnaire-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/sdoh-questionnaire-response"
      },
      "name" : "SDOH 社會決定因素問卷回覆實例",
      "description" : "王大同的精簡版 PRAPARE 社會風險問卷回覆結果。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SDOH-QuestionnaireResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "OperationDefinition-Bundle-submit.html"
      }],
      "reference" : {
        "reference" : "OperationDefinition/Bundle-submit"
      },
      "name" : "Submit Bundle Operation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-001.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-001"
      },
      "name" : "UC-001 一般健康檢查報告封包",
      "description" : "一般健康檢查結果 Document Bundle 打包範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-002.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-002"
      },
      "name" : "UC-002 勞工一般體格與健康檢查報告封包",
      "description" : "勞工一般健康檢查結果 Document Bundle 打包範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-003.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-003"
      },
      "name" : "UC-003 特殊危害健康作業檢查報告封包",
      "description" : "噪音/鉛/粉塵等特殊危害健康作業檢查報告封包。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-004.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-004"
      },
      "name" : "UC-004 企業自費健康檢查報告封包",
      "description" : "企業自費健檢報告封包，包含自費影像檢查及內視鏡檢查項目。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-005.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-005"
      },
      "name" : "UC-005 成人預防保健檢查報告封包",
      "description" : "國健署成人預防保健自填問卷與理學生化檢查 Document Bundle 範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-006.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-006"
      },
      "name" : "UC-006 勞工健康服務臨場服務紀錄封包",
      "description" : "臨場服務紀錄 Composition（附表八）與關聯活動資料 Document Bundle 範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-UC-007.html"
      }],
      "reference" : {
        "reference" : "Bundle/UC-007"
      },
      "name" : "UC-007 職業健康急診友善摘要封包",
      "description" : "急診友善摘要 Composition（含鉛作業暴露史、生命徵象、關鍵檢驗值與缺值示範）之 Document Bundle 範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Bundle-Document"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc001.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc001"
      },
      "name" : "一般健檢報告組成文件範例 (UC-001)",
      "description" : "整合王大同一般健康檢查所有關聯項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-LabResult-General.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-LabResult-General"
      },
      "name" : "一般健檢實驗室檢驗 Profile",
      "description" : "用於記錄勞工一般體格與健康檢查之實驗室檢驗結果，如血液、尿液及生化項目，繼承自 TW Core Lab Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-UnfitDiseases.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-UnfitDiseases"
      },
      "name" : "不適合從事作業之疾病值集",
      "description" : "依據勞工健康保護規則附表十二所列，不適合從事特定特別危害健康作業之疾病代碼值集（以 ICD-10-CM 表示）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-CoreUploadSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-CoreUploadSet"
      },
      "name" : "主管機關最小共通上傳集（國健署原案 21 列，跨值集群組）",
      "description" : "群組值集：組合 Core 之檢驗子集（VS-CoreDataset）、生理量測（VS-TWHAVitalSigns）與社會史碼，具體化主管機關（國健署）制定之最小共通上傳集（原案 16 主項／21 列，對標 USCDI regulator-defined minimum）。僅供文件與完整度／覆蓋矩陣機器核對，不作 Observation.code 綁定。嚼檳量／嚼檳月數屬本地 Extension（ext-betelnut-quantity），無國際碼，於文件註記。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Composition-ServiceRecord.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Composition-ServiceRecord"
      },
      "name" : "健康檢查健康服務執行紀錄組成結構 Profile",
      "description" : "本 Profile 用於定義臨場健康服務執行紀錄表單（附表八）的文件組成結構，以 Composition 作為文件核心。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-HealthManagementLevel.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-HealthManagementLevel"
      },
      "name" : "健康檢查健康管理分級 Observation Profile",
      "description" : "用於以獨立 Observation 資源記錄受檢勞工健康檢查後，經醫師總評判定之健康管理分級（1-4級）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Composition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Composition"
      },
      "name" : "健康檢查健檢報告組成結構 Profile",
      "description" : "本 Profile 用於定義一般健康檢查、勞工健康檢查及成人預防保健等健康檢查報告的文件組成結構，以 Composition 作為文件核心，並定義各項目的 Section，繼承自 TW Core Composition。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Encounter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Encounter"
      },
      "name" : "健康檢查健檢就醫事件 Profile",
      "description" : "本 Profile 用於描述勞工進行一般體格檢查、一般健康檢查或特殊體格/健康檢查的就醫事件，繼承自 TW Core Encounter。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-ImagingStudy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-ImagingStudy"
      },
      "name" : "健康檢查健檢影像檢查 Profile",
      "description" : "用於記錄勞工胸部 X 光、骨骼 X 光等影像檢查，繼承自 TW Core ImagingStudy。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-DiagnosticReport.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-DiagnosticReport"
      },
      "name" : "健康檢查健檢診斷報告 Profile",
      "description" : "本 Profile 用於彙整勞工體格及健康檢查結果之診斷報告，繼承自 TW Core DiagnosticReport。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-ServiceRequest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-ServiceRequest"
      },
      "name" : "健康檢查健檢追蹤檢查要求 Profile",
      "description" : "針對第三級或需要追蹤之勞工，醫師開立之追蹤檢查或現場評估排程要求，繼承自 TW Core ServiceRequest。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-ClinicalImpression.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-ClinicalImpression"
      },
      "name" : "健康檢查健檢醫師總評與分級 Profile",
      "description" : "用於記錄健檢判定醫師針對勞工檢查結果進行之總體臨床評估、健康管理分級（1-4級）及處置建議。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Bundle-Document.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Bundle-Document"
      },
      "name" : "健康檢查報告交換封包 (Document Bundle) Profile",
      "description" : "用於健檢報告交換的 Document Bundle，其第一個 entry 必須為 Composition，且型態 (type) 必須為 document。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-exam-interval.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-exam-interval"
      },
      "name" : "健康檢查實施週期擴充",
      "description" : "標註此次健康檢查之實施週期（如每年、每3年、每5年）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Occupation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Occupation"
      },
      "name" : "健康檢查工作經歷與職業別 Profile",
      "description" : "用於記錄受檢勞工之工作經歷與現任職業別，繼承自 TW Core Observation Occupation。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Organization-Employer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Organization-Employer"
      },
      "name" : "健康檢查所屬事業單位（雇主公司） Profile",
      "description" : "本 Profile 用於描述受檢勞工所屬之事業單位或公司，繼承自 TW Core Organization (公司) 以精確反映公司法人組織語義。其中統一編號以 identifier 表示。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Condition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Condition"
      },
      "name" : "健康檢查既往病史與不適作業疾病 Profile",
      "description" : "用於記錄勞工之既往慢性病病史，或醫師判定屬於附表十二不適合從事作業之疾病，繼承自 TW Core Condition。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-CoreDataset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-CoreDataset"
      },
      "name" : "健康檢查核心檢驗項目值集（主管機關最小上傳集之檢驗子集）",
      "description" : "Core 之檢驗子集（主管機關（國健署）最小共通上傳集之 Observation.code 綁定值集，綁定強度 extensible）。僅收錄 Core 之 10 檢驗項 preferred code 及其 acceptable 變異碼；生理量測（身高/體重/腰圍/血壓）碼分屬 VS-TWHAVitalSigns、社會史（吸菸/嚼檳）碼分屬 SocialHistory profile。Core 全集（21 列）之群組見 VS-CoreUploadSet。acceptable→preferred 歸一見 ConceptMap TWHealthCheckLaboratoryMap。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-TWHealthCheckLaboratoryMap.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/TWHealthCheckLaboratoryMap"
      },
      "name" : "健康檢查檢驗項目代碼對應 ConceptMap",
      "description" : "將健康檢查實驗室檢驗之 acceptable code 歸一至 preferred (primary) code。值集綁定採 extensible binding；本 ConceptMap 供接收端將院所 LIS 之可接受變異碼標準化至優先碼。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Questionnaire.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Questionnaire"
      },
      "name" : "健康檢查自覺症狀問卷定義 Profile",
      "description" : "用於定義勞工體格或健康檢查中，自覺症狀調查（附表十一之自覺症狀部分）的問卷結構 Profile。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Bundle-Transaction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Bundle-Transaction"
      },
      "name" : "健康檢查資料上傳封包 (Transaction Bundle) Profile",
      "description" : "用於健檢系統或醫療院所向主管機關平台進行批次上傳/新增資料之 Transaction Bundle，其型態 (type) 必須為 transaction，且 entry 必須包含 HTTP 請求方法資訊。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-TWHA-CapabilityStatement.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/TWHA-CapabilityStatement"
      },
      "name" : "健康檢查資料交換平台服務宣告",
      "description" : "本實體用於宣告健康檢查資料交換平台支援的交互作用規範，主要採用 POST [base]/Bundle ($submit) 或直接交易封包 (transaction) 進行健檢資料之上傳與交換。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-ExtendedDataset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-ExtendedDataset"
      },
      "name" : "健康檢查進階與領域擴充項目值集",
      "description" : "包含特殊健康檢查與體格檢查之實驗室與生理功能檢驗項目，以及自費健康檢查常見之影像學檢查（如 MRI、CT、PET/CT、超音波、骨密度等）與內視鏡檢查（如胃鏡、大腸鏡），對應至 LOINC 代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-CarePlan.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-CarePlan"
      },
      "name" : "健康檢查適性配工計畫 Profile",
      "description" : "用於針對第四級健康管理勞工，由醫師、事業單位等共同制定之適性配工計畫（變更場所、工作或縮短工時等），繼承自 TW Core CarePlan。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-HealthMgmtLevel.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-HealthMgmtLevel"
      },
      "name" : "健康管理分級代碼系統",
      "description" : "依據勞工健康保護規則第 21 條規定，醫師依健康檢查結果判定之健康管理分級。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-HealthMgmtLevel.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-HealthMgmtLevel"
      },
      "name" : "健康管理分級值集",
      "description" : "包含健康管理分級（第一級至第四級）代碼之值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-health-mgmt-level.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-health-mgmt-level"
      },
      "name" : "健康管理分級擴充",
      "description" : "記錄醫師針對勞工健康狀況判定之健康管理分級（1-4級）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Procedure-Counseling.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Procedure-Counseling"
      },
      "name" : "健康諮詢與衛教指導 Profile",
      "description" : "用於記錄成人預防保健服務及一般健康檢查中，醫師或醫護團隊提供之健康諮詢、衛教指導與預防教育活動（如戒菸、節酒、腎病識能指導等），繼承自 TW Core Procedure。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-example-procedure-counseling.html"
      }],
      "reference" : {
        "reference" : "Procedure/example-procedure-counseling"
      },
      "name" : "健康諮詢與衛教指導範例",
      "description" : "針對受檢者王大同進行之「規律運動諮詢與衛教」與「腎病識能衛教指導」的紀錄。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Procedure-Counseling"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-HealthCounseling.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-HealthCounseling"
      },
      "name" : "健康諮詢與衛教指導項目代碼系統",
      "description" : "國民健康署成人預防保健服務及一般健康檢查中醫師提供之健康諮詢與衛教指導項目。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-HealthCounseling.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-HealthCounseling"
      },
      "name" : "健康諮詢與衛教指導項目值集",
      "description" : "包含成人預防保健與健康檢查中健康諮詢項目代碼之值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-example-encounter-general.html"
      }],
      "reference" : {
        "reference" : "Encounter/example-encounter-general"
      },
      "name" : "健檢就醫事件範例 - 一般定期健康檢查",
      "description" : "受檢勞工王大同於115年6月12日進行的一般定期健康檢查事件。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Encounter"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-LaborReportCode.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-LaborReportCode"
      },
      "name" : "勞動部通報報告代碼值集",
      "description" : "包含勞動部通報報告類別代碼之值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-labor-report-code.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-labor-report-code"
      },
      "name" : "勞動部通報報告代碼擴充",
      "description" : "標註此檢查結果通報至勞動部時所採用之報告大類代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-LaborReportCode.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-LaborReportCode"
      },
      "name" : "勞動部通報報告代碼系統",
      "description" : "勞工健檢結果通報勞動部（LABOR）系統時所使用之報告類別代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc002.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc002"
      },
      "name" : "勞工一般體格與健康檢查報告組成文件範例 (UC-002)",
      "description" : "整合王大同勞工一般健康檢查關聯項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-OccHealthCheck-Required.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-OccHealthCheck-Required"
      },
      "name" : "勞工健康檢查法定必驗項目值集（第一期草案）",
      "description" : "第一期法定必驗之勞工健康檢查項目草案子集，涵蓋附表九一般必驗生理量測與實驗室項目，以及噪音／鉛／粉塵三模組之核心必驗代碼。此為初版草案，範疇待附表九/十逐項法規盤點確認後修訂。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-employment-date.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-employment-date"
      },
      "name" : "受僱日期擴充",
      "description" : "記錄受檢勞工於事業單位之受僱日期。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-example-worker.html"
      }],
      "reference" : {
        "reference" : "Patient/example-worker"
      },
      "name" : "受檢勞工範例 - 王大同",
      "description" : "一名在電子公司化學處理課工作的勞工王大同之基本資料與雇主資訊。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Patient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Patient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Patient"
      },
      "name" : "受檢者 Profile",
      "description" : "本 Profile 用於描述接受健康檢查（含一般健檢、勞工健檢與成人預防保健）之受檢者，繼承自 TW Core Patient，並可選擴充記錄其所屬事業單位、受僱日期與所屬部門。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SocialHistory-Smoking.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SocialHistory-Smoking"
      },
      "name" : "吸菸歷史與狀態 Profile",
      "description" : "用於記錄勞工之吸菸狀態與吸菸量、戒菸時間等資訊，繼承自 TW Core Observation Smoking Status。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-SmokingStatus.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-SmokingStatus"
      },
      "name" : "吸菸狀態代碼系統",
      "description" : "勞工健檢生活習慣調查中之吸菸狀態分類。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-SmokingStatus.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-SmokingStatus"
      },
      "name" : "吸菸狀態值集",
      "description" : "包含吸菸狀態代碼的值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-smoking.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-smoking"
      },
      "name" : "吸菸狀態與菸量範例",
      "description" : "受檢勞工王大同的吸菸史（從未吸菸）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SocialHistory-Smoking"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-smoking-quantity.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-smoking-quantity"
      },
      "name" : "吸菸量及菸齡擴充",
      "description" : "記錄每日吸菸支數與吸菸年數。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-BetNutChewYear-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-BetNutChewYear-codesystem"
      },
      "name" : "嚼檳榔年代碼系統",
      "description" : "Betel Nut Chewing Year Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-sf-BetNutChewYear-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/sf-BetNutChewYear-valueset"
      },
      "name" : "嚼檳榔年值集",
      "description" : "Betel Nut Chewing Year Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SocialHistory-BetelNut.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SocialHistory-BetelNut"
      },
      "name" : "嚼檳榔歷史與狀態 Profile",
      "description" : "用於記錄勞工之嚼檳榔習慣與量化資料。本 Profile 基於 Observation 資源，採用與臺灣癌症登記短表實作指引 (TWCR_SF) 相同之元件架構及值集，以便進行跨系統之整合介接。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-betelnut.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-betelnut"
      },
      "name" : "嚼檳榔狀態與量化資料範例",
      "description" : "受檢勞工王大同的嚼檳榔習慣，每日嚼食 5 顆，嚼檳 10 年，目前已戒除 1 年（12個月）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SocialHistory-BetelNut"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-sf-BetNutChewBeh-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/sf-BetNutChewBeh-valueset"
      },
      "name" : "嚼檳榔行為值集",
      "description" : "Betel Nut Chewing Behavior Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-adult-preventive-care-questionnaire.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/adult-preventive-care-questionnaire"
      },
      "name" : "國健署成人預防保健生活習慣與既往病史問卷定義",
      "description" : "用於記錄國民健康署成人預防保健服務之健康行為、生活習慣與個人及家族病史自填問卷項目。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Questionnaire"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Practitioner.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Practitioner"
      },
      "name" : "執業/健檢醫護與服務人員 Profile",
      "description" : "本 Profile 用於描述實施勞工體格檢查、健康檢查或臨場健康服務之醫師、護理人員、職安人員等，繼承自 TW Core Practitioner。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-example-doctor.html"
      }],
      "reference" : {
        "reference" : "Practitioner/example-doctor"
      },
      "name" : "執業醫護人員範例 - 林職醫",
      "description" : "實施勞工體格及健康檢查評估並判定分級之林職醫師。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Organization-Facility.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Organization-Facility"
      },
      "name" : "實施健康檢查之醫療機構 Profile",
      "description" : "本 Profile 用於描述實施勞工體格檢查、健康檢查或提供臨場健康服務之醫療機構，繼承自 TW Core Organization (醫院) 以精確反映醫療機構語義。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-example-hospital.html"
      }],
      "reference" : {
        "reference" : "Organization/example-hospital"
      },
      "name" : "實施健檢之醫療機構範例 - 航空醫務中心",
      "description" : "實施體格檢查及健康檢查之交通部民用航空局航空醫務中心。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Organization-Facility"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-lab-glucose.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-lab-glucose"
      },
      "name" : "實驗室檢驗範例 - 空腹血糖",
      "description" : "受檢勞工王大同的空腹血糖檢驗結果 (95 mg/dL)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-LabResult-General"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-lab-egfr-absent.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-lab-egfr-absent"
      },
      "name" : "實驗室檢驗缺值範例 - eGFR 未檢測（dataAbsentReason）",
      "description" : "受檢勞工王大同本次因故未完成腎絲球過濾率 (eGFR) 檢測。示範以 dataAbsentReason = not-performed 標明缺值原因，Observation 仍保留且合乎 twha-obs-1（value 或 dataAbsentReason 或 component 三者擇一）。eGFR 屬成健延伸項目，v3.0 Core 重構後歸 Extended，故綁 TWHA-LabResult-Special（VS-ExtendedDataset）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-LabResult-Special"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-ECG.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-ECG"
      },
      "name" : "心電圖檢查 Profile",
      "description" : "用於記錄勞工心電圖檢查結果，通常於高溫作業特殊健檢中實施，繼承自 TW Core Observation ECG（v1.0.0 新增之心電圖專用 Profile）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-QuestionnaireResponse-HT.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-QuestionnaireResponse-HT"
      },
      "name" : "成人預防保健問卷回覆 Profile",
      "description" : "用於記錄成人預防保健（國健署成人預防保健服務）之自覺症狀與生活習慣問卷回覆，繼承自 TW Core QuestionnaireResponse。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-adult-preventive-care-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/adult-preventive-care-response"
      },
      "name" : "成人預防保健問卷回覆實例",
      "description" : "王大同的成人預防保健生活習慣自填問卷回覆結果。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-QuestionnaireResponse-HT"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc005.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc005"
      },
      "name" : "成人預防保健檢查報告組成文件範例 (UC-005)",
      "description" : "整合王大同成人預防保健與生活習慣問卷項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-BetNutChewQuit-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-BetNutChewQuit-codesystem"
      },
      "name" : "戒嚼檳榔年代碼系統",
      "description" : "Betel Nut Chewing Quit Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-sf-BetNutChewQuit-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/sf-BetNutChewQuit-valueset"
      },
      "name" : "戒嚼檳榔年值集",
      "description" : "Betel Nut Chewing Quit Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-cessation-duration.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-cessation-duration"
      },
      "name" : "戒除時間（戒菸/戒檳榔月數）擴充",
      "description" : "記錄受檢者已戒菸或已戒檳榔的月數。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-past-condition.html"
      }],
      "reference" : {
        "reference" : "Condition/example-past-condition"
      },
      "name" : "既往病史範例 - 高血壓",
      "description" : "受檢勞工王大同的高血壓既往病史。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Condition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-OrganicSolventType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-OrganicSolventType"
      },
      "name" : "有機溶劑種類代碼系統",
      "description" : "特別危害健康作業中之有機溶劑種類（主要 7 種）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-OrganicSolventType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-OrganicSolventType"
      },
      "name" : "有機溶劑種類值集",
      "description" : "包含特別危害健康作業中之常見有機溶劑代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Group"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Group-example-group-workers.html"
      }],
      "reference" : {
        "reference" : "Group/example-group-workers"
      },
      "name" : "服務對象勞工群組範例",
      "description" : "大同電子現場化學製造部門之作業勞工群組。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-ExamType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-ExamType"
      },
      "name" : "檢查類型代碼系統",
      "description" : "勞工體格及健康檢查之類型，包含一般體格檢查、一般健康檢查、特殊體格檢查及特殊健康檢查。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-ExamType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-ExamType"
      },
      "name" : "檢查類型值集",
      "description" : "包含一般體格檢查、一般健康檢查、特殊體格檢查及特殊健康檢查之代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-exam-type.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-exam-type"
      },
      "name" : "檢查類型擴充",
      "description" : "標註該就醫事件（Encounter）是屬於一般體格、一般健康、特殊體格或特殊健康檢查。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-BetNutChewAmount-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-BetNutChewAmount-codesystem"
      },
      "name" : "每日嚼檳榔量代碼系統",
      "description" : "Betel Nut Chewing Amount Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-sf-BetNutChewAmount-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/sf-BetNutChewAmount-valueset"
      },
      "name" : "每日嚼檳榔量值集",
      "description" : "Betel Nut Chewing Amount Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-exposure-lead.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-exposure-lead"
      },
      "name" : "特別危害作業暴露史範例 - 鉛作業",
      "description" : "受檢勞工王大同從事鉛作業之暴露史，暴露年數 8 年，工作性質為電池極板熔鉛作業。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-WorkExposure"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-WorkExposure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-WorkExposure"
      },
      "name" : "特別危害健康作業危害因子暴露史 Profile",
      "description" : "用於記錄受檢勞工從事特別危害作業（如高溫、噪音、鉛、粉塵等）之暴露年數與詳細工作性質。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-HazardType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-HazardType"
      },
      "name" : "特別危害健康作業類別代碼系統",
      "description" : "勞工健康保護規則所定義之特別危害健康作業，歸併為 12 危害家族（家族層）。附表十（115.06.26 修正）逐號列舉之 35 項法定具名作業另以 CS-Appendix10Operation 表示，家族 ↔ 具名作業之對映見 ConceptMap Appendix10-to-HazardType。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-HazardType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-HazardType"
      },
      "name" : "特別危害健康作業類別值集",
      "description" : "包含 12 大類特別危害健康作業類別之代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-hazard-type.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-hazard-type"
      },
      "name" : "特別危害健康作業類別擴充",
      "description" : "標註該特殊體格或健康檢查所針對的危害作業種類（12大類）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-SpecificChemicalType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-SpecificChemicalType"
      },
      "name" : "特定化學物質種類代碼系統",
      "description" : "特別危害健康作業中之特定化學物質種類。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-SpecificChemicalType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-SpecificChemicalType"
      },
      "name" : "特定化學物質種類值集",
      "description" : "包含特別危害健康作業中之常見特定化學物質代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-LabResult-Special.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-LabResult-Special"
      },
      "name" : "特殊健檢實驗室檢驗 Profile",
      "description" : "用於記錄特別危害健康作業勞工之特殊實驗室檢驗結果（如血中鉛等），繼承自 TW Core Lab Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc003.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc003"
      },
      "name" : "特殊危害健康作業檢查報告組成文件範例 (UC-003)",
      "description" : "整合王大同噪音/鉛/粉塵特殊危害作業檢查項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-physical.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-physical"
      },
      "name" : "理學檢查結果範例",
      "description" : "受檢勞工王大同各系統理學檢查結果（正常）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-PhysicalExam"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-sf-ObserBeh-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/sf-ObserBeh-codesystem"
      },
      "name" : "相關行為代碼系統",
      "description" : "Observation Behavior Code System",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SocialHistory-Sleep.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SocialHistory-Sleep"
      },
      "name" : "睡眠狀況 Profile",
      "description" : "用於記錄勞工之平均每日睡眠時間（以小時計）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-sleep.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-sleep"
      },
      "name" : "睡眠狀況測量範例",
      "description" : "受檢勞工王大同的平均每日睡眠時間 (7 小時)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-SocialHistory-Sleep"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SDOH-QuestionnaireResponse.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SDOH-QuestionnaireResponse"
      },
      "name" : "社會決定因素 (SDOH) 問卷回覆 Profile",
      "description" : "用於記錄受檢者之社會決定因素問卷結果（基於精簡版 PRAPARE 社會風險問卷），繼承自 TW Core QuestionnaireResponse。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-twha-sdoh-questionnaire.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/twha-sdoh-questionnaire"
      },
      "name" : "精簡版 PRAPARE 社會風險問卷定義",
      "description" : "包含教育程度、就業狀態、居住環境安全、主要照顧壓力與經濟困難等 5 個核心社會決定因素 (SDOH) 欄位之問卷。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Questionnaire"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Composition-EmergencySummary.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Composition-EmergencySummary"
      },
      "name" : "職業健康急診友善摘要 Composition Profile",
      "description" : "職業健康急診友善摘要（Occupational Health Emergency Summary）。當勞工於急診就醫時，供急診醫師快速掌握其特別危害作業暴露史、關鍵生命徵象與檢驗值、以及健康管理分級。以 Composition 承載，將既有之暴露史（TWHA-WorkExposure）、生命徵象、CBC／肝腎功能等關鍵檢驗與總評分級以 section.entry 引用，形成可驗證、可交換的摘要文件。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-emergency-summary.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-emergency-summary"
      },
      "name" : "職業健康急診友善摘要範例 (UC-007)",
      "description" : "整合王大同鉛作業暴露史、生命徵象與關鍵檢驗值之急診友善摘要，供急診醫師快速掌握其職業暴露背景。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition-EmergencySummary"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-VitalSigns.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-VitalSigns"
      },
      "name" : "職業健檢生命徵象 Profile",
      "description" : "用於記錄勞工身高、體重、腰圍等基本生理特徵，繼承自 TW Core Vital Signs。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-TWHAVitalSigns.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-TWHAVitalSigns"
      },
      "name" : "職業健檢生命徵象項目值集",
      "description" : "包含身高、體重、腰圍及血壓等生理測量項目之 LOINC 代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-HearingTest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-HearingTest"
      },
      "name" : "聽力檢查 Profile",
      "description" : "用於記錄勞工純音聽力測試結果，依左右耳及頻率（0.5/1/2/3/4/6/8 kHz）分切片記錄。繼承自 TW Core Observation Clinical Result。v1.1 修正：更正並補齊純音氣導聽閾 LOINC 代碼（原 v3 之頻率×耳別代碼多處錯置，且缺 3/6/8 kHz），使各切片代碼與 LOINC「Pure tone threshold audiometry panel」(89015-2) 之成員一致，符合《勞工健康保護規則》附表十噪音作業之 0.5–8 kHz 全頻率要求。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-hearing.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-hearing"
      },
      "name" : "聽力檢查結果範例",
      "description" : "受檢勞工王大同的純音聽力測試結果（左右耳 0.5–8 kHz 各頻率聽力閾值均在正常範圍 ≤25 dB）。v1.1 更新：使用正確 Panel code 89015-2 及更正／補齊之頻率×耳別切片（0.5/1/2/3/4/6/8 kHz）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-HearingTest"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-PulmonaryFunction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-PulmonaryFunction"
      },
      "name" : "肺功能檢查 Profile",
      "description" : "用於記錄勞工肺功能檢查結果（主要包括 FVC, FEV1, FEV1/FVC），繼承自 TW Core Observation Clinical Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-pulmonary.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-pulmonary"
      },
      "name" : "肺功能檢查結果範例",
      "description" : "受檢勞工王大同的肺功能檢查結果（FVC = 4.2 L, FEV1 = 3.5 L, FEV1/FVC = 83.3%）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-PulmonaryFunction"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-PulmonaryFunction.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-PulmonaryFunction"
      },
      "name" : "肺功能檢查項目值集",
      "description" : "包含常用之肺功能檢查（如 FVC, FEV1, FEV1/FVC 等）的 LOINC 代碼，以供肺功能檢查 Profile 使用。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-waist.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-waist"
      },
      "name" : "腰圍測量結果範例",
      "description" : "受檢勞工王大同的腰圍測量結果 (82 cm)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VitalSigns"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Encounter-Service.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Encounter-Service"
      },
      "name" : "臨場健康服務事件 Profile",
      "description" : "本 Profile 用於描述醫護團隊到事業單位提供臨場健康服務之就醫/諮詢事件（對應附表八）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Task-ServiceTask.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Task-ServiceTask"
      },
      "name" : "臨場健康服務建議與改善任務 Profile",
      "description" : "用於記錄臨場服務中針對發現問題所提出之改善建議措施，以及追蹤前次改善事項之落實情形（對應附表八）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Observation-ServiceFinding.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Observation-ServiceFinding"
      },
      "name" : "臨場健康服務發現問題/風險 Profile",
      "description" : "用於記錄臨場健康服務中發現之作業場所問題、健康危害或風險（附表八）。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-ServiceActivityType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-ServiceActivityType"
      },
      "name" : "臨場健康服務辦理事項代碼系統",
      "description" : "附表八中醫護人員辦理之臨場健康服務項目活動類別代碼系統。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-ServiceActivityType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-ServiceActivityType"
      },
      "name" : "臨場健康服務辦理事項值集",
      "description" : "包含臨場健康服務項目活動類別代碼之值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-example-encounter-service.html"
      }],
      "reference" : {
        "reference" : "Encounter/example-encounter-service"
      },
      "name" : "臨場服務事件範例",
      "description" : "林職醫師與護理師於115年6月10日前往大同電子股份有限公司進行現場臨場服務。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Encounter-Service"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-Procedure-ServiceActivity.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-Procedure-ServiceActivity"
      },
      "name" : "臨場服務執行活動項目 Profile",
      "description" : "用於記錄醫護人員在臨場健康服務中實際辦理之活動項目（對應附表八之臨場健康服務執行情形），繼承自 TW Core Procedure。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-example-procedure-activity.html"
      }],
      "reference" : {
        "reference" : "Procedure/example-procedure-activity"
      },
      "name" : "臨場服務執行活動項目範例",
      "description" : "在臨場服務中辦理「健康檢查結果分析」的執行紀錄。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Procedure-ServiceActivity"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-example-service-task.html"
      }],
      "reference" : {
        "reference" : "Task/example-service-task"
      },
      "name" : "臨場服務建議改善措施與追蹤任務範例",
      "description" : "林職醫師針對現場發現問題提出之改善建議，交由雇主大同電子執行改善。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Task-ServiceTask"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-example-service-finding.html"
      }],
      "reference" : {
        "reference" : "Observation/example-service-finding"
      },
      "name" : "臨場服務現場發現問題範例",
      "description" : "臨場服務中發現作業現場危害因子及問題。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Observation-ServiceFinding"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-example-composition-service.html"
      }],
      "reference" : {
        "reference" : "Composition/example-composition-service"
      },
      "name" : "臨場服務紀錄組成文件範例 (UC-006)",
      "description" : "整合大同電子 115年6月份臨場服務紀錄（附表八）的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition-ServiceRecord"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-QuestionnaireResponse.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-QuestionnaireResponse"
      },
      "name" : "自覺症狀問卷回覆 Profile",
      "description" : "用於記錄勞工所填寫之自覺症狀問卷結果，必須關聯至受檢勞工，繼承自 TW Core QuestionnaireResponse。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-example-symptoms-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/example-symptoms-response"
      },
      "name" : "自覺症狀問卷回覆範例",
      "description" : "受檢勞工王大同的自覺症狀問卷填寫結果。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-QuestionnaireResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-example-questionnaire.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/example-questionnaire"
      },
      "name" : "自覺症狀問卷定義範例",
      "description" : "自覺症狀調查問卷結構定義。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Questionnaire"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-composition-uc004.html"
      }],
      "reference" : {
        "reference" : "Composition/composition-uc004"
      },
      "name" : "自費健康檢查與進階影像鏡檢報告組成文件範例 (UC-004)",
      "description" : "整合王大同自費影像造影與內視鏡檢查項目的 Composition 臨床文件範例。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Composition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-mammo.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-mammo"
      },
      "name" : "自費健檢項目 - 乳房攝影",
      "description" : "自費健檢中乳房攝影檢查的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-pet.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-pet"
      },
      "name" : "自費健檢項目 - 全身正子造影",
      "description" : "自費健檢中全身正子造影 (FDG PET/CT) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-endoscopy-colon.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-endoscopy-colon"
      },
      "name" : "自費健檢項目 - 大腸鏡檢查",
      "description" : "自費健檢中下消化道大腸鏡鏡檢 (Colonoscopy) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-cta.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-cta"
      },
      "name" : "自費健檢項目 - 心臟冠狀動脈電腦斷層血管攝影",
      "description" : "自費健檢中心臟冠狀動脈電腦斷層血管攝影 (Cardiac CTA) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-lung-ct.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-lung-ct"
      },
      "name" : "自費健檢項目 - 肺部低劑量電腦斷層",
      "description" : "自費健檢中肺部低劑量電腦斷層 (LDCT) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-endoscopy-egd.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-endoscopy-egd"
      },
      "name" : "自費健檢項目 - 胃鏡檢查",
      "description" : "自費健檢中上消化道胃鏡鏡檢 (EGD) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-imaging-brain-mri.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-imaging-brain-mri"
      },
      "name" : "自費健檢項目 - 腦部核磁共振造影",
      "description" : "自費健檢中腦部核磁共振造影 (Brain MRI) 的結果紀錄。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-bloodpressure.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-bloodpressure"
      },
      "name" : "血壓測量結果範例",
      "description" : "受檢勞工王大同的血壓測量結果 (120/80 mmHg)，繼承自 TW Core Blood Pressure。",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-vision.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-vision"
      },
      "name" : "視力及辨色力檢查結果範例",
      "description" : "受檢勞工王大同的視力（裸視左/右 1.0）及辨色力（正常）檢查結果。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VisionTest"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-VisionTest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-VisionTest"
      },
      "name" : "視力與辨色力檢查 Profile",
      "description" : "用於記錄勞工眼部檢查結果，包含左右眼裸視/矯正視力及辨色力項目，繼承自 TW Core Observation Clinical Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-PhysicalExamSystems.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-PhysicalExamSystems"
      },
      "name" : "身體檢查系統部位代碼系統",
      "description" : "附表十一理學檢查中所涉及之身體系統部位分類。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-PhysicalExamSystems.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-PhysicalExamSystems"
      },
      "name" : "身體檢查系統部位值集",
      "description" : "包含理學檢查中各系統部位代碼之值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-PhysicalExam.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-PhysicalExam"
      },
      "name" : "身體理學檢查 Profile",
      "description" : "用於記錄勞工身體各系統（頭頸部、呼吸、心血管、消化、神經、肌肉骨骼、皮膚）之理學檢查結果，繼承自 TW Core Observation Clinical Result。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-bmi.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-bmi"
      },
      "name" : "身體質量指數 (BMI) 測量結果範例",
      "description" : "受檢勞工王大同的身體質量指數 (BMI) 測量結果 (22.86 kg/m2)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VitalSigns"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-height.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-height"
      },
      "name" : "身高測量結果範例",
      "description" : "受檢勞工王大同的身高測量結果 (175 cm)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VitalSigns"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-FitnessForWork.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-FitnessForWork"
      },
      "name" : "適性配工建議代碼系統",
      "description" : "第四級管理中，醫師針對受檢勞工提出之適性配工或變更作業內容建議。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-FitnessForWork.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-FitnessForWork"
      },
      "name" : "適性配工建議值集",
      "description" : "包含適性配工或工作調整建議代碼之值集。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-fitness-for-work.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-fitness-for-work"
      },
      "name" : "適性配工建議項目擴充",
      "description" : "用於 CarePlan 中標註具體的適性配工或變更作業場所等建議項目。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-department.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-department"
      },
      "name" : "部門/課別擴充",
      "description" : "記錄受檢勞工於事業單位中所屬之部門、課別或課室名稱。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClinicalImpression"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClinicalImpression-example-clinical-impression.html"
      }],
      "reference" : {
        "reference" : "ClinicalImpression/example-clinical-impression"
      },
      "name" : "醫師臨床總評與分級範例",
      "description" : "林職醫師針對王大同的健康檢查結果進行之總評，判定為第一級健康管理（正常）。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-ClinicalImpression"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-Appendix10-to-HazardType.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/Appendix10-to-HazardType"
      },
      "name" : "附表十 35 項法定作業 對 12 危害家族 對照",
      "description" : "將 CS-Appendix10Operation（附表十 35 項具名作業）對映至 CS-HazardType（12 危害家族）。每一具名作業（source）相對於其對應之危害家族（target）在語意上較窄，故 equivalence = narrower（家族涵蓋範圍較廣）。供接收端由法定作業編號歸併至危害家族，回應審查意見之逐號可追溯性需求。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VS-Appendix10-Operation.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VS-Appendix10-Operation"
      },
      "name" : "附表十特別危害健康作業值集（35 項）",
      "description" : "包含《勞工健康保護規則》附表十 35 項法定具名作業之代碼。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CS-Appendix10Operation.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CS-Appendix10Operation"
      },
      "name" : "附表十特別危害健康作業具名代碼系統",
      "description" : "《勞工健康保護規則》附表十（115.06.26 修正）逐號列舉之 35 項特別危害健康作業具名代碼。本代碼系統為「具名作業層」，與 CS-HazardType（12 危害家族層）以 ConceptMap Appendix10-to-HazardType 對映。編號 33/34/35（苯乙烯、甲苯、二甲苯）為 115.06.26 修正新增。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-example-employer.html"
      }],
      "reference" : {
        "reference" : "Organization/example-employer"
      },
      "name" : "雇主事業單位範例 - 大同電子",
      "description" : "受檢勞工王大同所屬之事業單位組織資料。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-Organization-Employer"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-employer-info.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-employer-info"
      },
      "name" : "雇主事業單位資訊擴充",
      "description" : "關聯受檢勞工所屬之事業單位組織資料，或臨場服務事件/活動所針對之事業單位。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TWHA-SocialHistory-Alcohol.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TWHA-SocialHistory-Alcohol"
      },
      "name" : "飲酒歷史與狀態 Profile",
      "description" : "用於記錄勞工之飲酒習慣歷史與狀態。",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-obs-weight.html"
      }],
      "reference" : {
        "reference" : "Observation/obs-weight"
      },
      "name" : "體重測量結果範例",
      "description" : "受檢勞工王大同的體重測量結果 (70 kg)。",
      "exampleCanonical" : "https://twcore.mohw.gov.tw/ig/twha/StructureDefinition/TWHA-VitalSigns"
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "adult-preventive-care.html"
        }],
        "nameUrl" : "adult-preventive-care.html",
        "title" : "Adult Preventive Care",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "background.html"
        }],
        "nameUrl" : "background.html",
        "title" : "Background",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "conformance.html"
        }],
        "nameUrl" : "conformance.html",
        "title" : "Conformance",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "datamodel.html"
        }],
        "nameUrl" : "datamodel.html",
        "title" : "Datamodel",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "general-exam.html"
        }],
        "nameUrl" : "general-exam.html",
        "title" : "General Exam",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "health-management.html"
        }],
        "nameUrl" : "health-management.html",
        "title" : "Health Management",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "security.html"
        }],
        "nameUrl" : "security.html",
        "title" : "Security",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "service-record.html"
        }],
        "nameUrl" : "service-record.html",
        "title" : "Service Record",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "special-exam.html"
        }],
        "nameUrl" : "special-exam.html",
        "title" : "Special Exam",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "terminology.html"
        }],
        "nameUrl" : "terminology.html",
        "title" : "Terminology",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "usecases.html"
        }],
        "nameUrl" : "usecases.html",
        "title" : "Usecases",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
